# blooket-proxy-worker

A single self-contained Cloudflare Worker that:

1. Hosts a **TOMPHTTP Bare server** at `/bare/` (v1 + v2, HTTP + WebSocket)
   using an **in-memory** database — **no KV namespace required**.
2. Hosts a **server-side browse proxy** at `/browse/<absolute-url>` that
   fetches the remote URL on the worker's behalf, rewrites every URL inside
   HTML / CSS / JS / JSON so they also flow through `/browse/`, and
   auto-injects the **Blooket cheats script** into every `play.blooket.com`
   response.
3. Serves a **landing page** at `/` with a "Launch play.blooket.com
   (with cheats)" button.

This zip contains exactly two files:

```
index.js              <- the bundled worker (ES Modules, ~110 KB, zero
                         external imports, zero bindings required)
README.md             <- this file
```

## Upload via the Cloudflare dashboard

1. Go to **Cloudflare dashboard → Workers & Pages → Create → Upload**.
2. Drag this zip (or just the `index.js` inside it) into the uploader.
3. Give the Worker a name and click **Deploy**.
4. Open the Worker URL in a browser. You'll see the landing page. Click
   **Launch play.blooket.com (with cheats)**.

No `wrangler.toml`, no `npm install`, no KV namespace, no bindings to
configure. The dashboard uploader will accept it as-is.

## Routes

| Method | Path                          | What it does                                            |
|--------|-------------------------------|---------------------------------------------------------|
| GET    | `/`                           | Landing page (inlined `index.html`).                    |
| GET    | `/cheats.js`                  | Blooket cheats script (inlined).                        |
| GET    | `/shim.js?orig=<url>`         | Per-request shim that defines `window.__blPath()` etc.  |
| ANY    | `/browse/<absolute-url>`      | Proxied remote content (HTML/CSS/JS/JSON/...).          |
| ANY    | `/bare/*`                     | TOMPHTTP Bare server v1 + v2 (HTTP + WebSocket).        |

## Use the Bare endpoint directly

If you have an existing Bare client (Ultraviolet, `@mercuryworkshop/bare-mux`,
wisp, etc.), point its `bare` config at:

```
https://<your-worker>.workers.dev/bare/
```

## Use the browse proxy directly

```
https://<your-worker>.workers.dev/browse/https://play.blooket.com/play
```

The cheats are only injected for hosts in the `INJECT_HOSTS` set in
`src/browse.ts` (`play.blooket.com`, `www.blooket.com`, `blooket.com`).
Every other URL is proxied as-is.

## About the in-memory database

The bare server uses an in-memory `Map<string, string>` for WebSocket meta
state (the `v1/ws-new-meta` + `v1/ws-meta` + `v2/ws-new-meta` + `v2/ws-meta`
endpoints). This means WebSocket tunneling works within a single isolate's
lifetime, but meta state does not persist across isolate restarts. For the
typical Blooket cheats use case this is fine — the cheats open a fresh
WebSocket connection per game session and don't depend on long-lived
meta across restarts.

If you ever want persistent WebSocket state, create a KV namespace in the
dashboard and bind it as `BARE`. The source supports it — the bundle
doesn't, because the whole point of this zip is zero-config upload.

## How the bundle was produced

The full TypeScript source lives at
`/home/z/my-project/blooket-proxy-worker/`. `npm run bundle` runs esbuild
against `src/dashboard-entry.ts`, inlines `public/index.html` and
`public/cheats.js` as string constants via `?raw` imports, replaces the
`http-errors` npm dependency with a minimal shim
(`src/bare/http-errors-shim.ts`), and emits a single ES Modules
`dist/index.js` with zero external imports.

## Credits

- Bare server: [TompHTTP / bare-server-worker](https://github.com/tomphttp/bare-server-worker) (GPL-3.0)
- Blooket cheats: [Blooket-Council / Blooket-Cheats](https://github.com/Blooket-Council/Blooket-Cheats) by 05Konzz - mobileGui build v5.26.24

## License

GPL-3.0-only (inherited from the vendored bare-server-worker source).
