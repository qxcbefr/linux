/*
 * blooket-proxy-worker - dashboard-uploadable bundle
 *
 * Single-file Cloudflare Worker that:
 *   - hosts a TOMPHTTP Bare server at /bare/        (vendored bare-server-worker)
 *   - hosts a server-side browse proxy at /browse/  (auto-injects the blooket cheats)
 *   - serves a landing page at /
 *
 * Generated 2026-11-19T13:13:38.222Z
 * Original sources: https://github.com/tomphttp/bare-server-worker (GPL-3.0)
 *                   https://github.com/Blooket-Council/Blooket-Cheats
 */


// src/bare/http-errors-shim.ts
var HttpErrorImpl = class _HttpErrorImpl extends Error {
  status;
  statusCode;
  expose;
  constructor(status, message) {
    super(message || `HTTP ${status}`);
    this.status = status;
    this.statusCode = status;
    this.expose = status >= 400 && status < 500;
    Object.setPrototypeOf(this, _HttpErrorImpl.prototype);
  }
};
var statusText = {
  400: "Bad Request",
  401: "Unauthorized",
  402: "Payment Required",
  403: "Forbidden",
  404: "Not Found",
  405: "Method Not Allowed",
  406: "Not Acceptable",
  409: "Conflict",
  410: "Gone",
  429: "Too Many Requests",
  500: "Internal Server Error",
  501: "Not Implemented",
  502: "Bad Gateway",
  503: "Service Unavailable",
  504: "Gateway Timeout"
};
function create(status, message) {
  return new HttpErrorImpl(status, message || statusText[status]);
}
create.isHttpError = function(obj) {
  return obj instanceof HttpErrorImpl || obj instanceof Error && typeof obj.status === "number" && typeof obj.statusCode === "number";
};
for (const code of Object.keys(statusText)) {
  const status = parseInt(code, 10);
  const camel = statusText[status].replace(/\s+(\w)/g, (_, c) => c.toUpperCase());
  const factory = function() {
    return create(status);
  };
  create[camel] = factory;
}
var http_errors_shim_default = create;

// src/bare/BareServer.ts
var BareError = class extends Error {
  status;
  body;
  constructor(status, body) {
    super(body.message || body.code);
    this.status = status;
    this.body = body;
  }
};
var project = {
  name: "bare-server-worker",
  description: "TOMPHTTP Cloudflare Bare Server",
  repository: "https://github.com/tomphttp/bare-server-worker",
  version: "1.2.2"
};
function json(status, json2) {
  return new Response(JSON.stringify(json2, null, "	"), {
    status,
    headers: {
      "content-type": "application/json"
    }
  });
}
var Server = class extends EventTarget {
  routes = /* @__PURE__ */ new Map();
  socketRoutes = /* @__PURE__ */ new Map();
  closed = false;
  directory;
  options;
  /**
   * @internal
   */
  constructor(directory, options) {
    super();
    this.directory = directory;
    this.options = options;
  }
  /**
   * Remove all timers and listeners
   */
  close() {
    this.closed = true;
    this.dispatchEvent(new Event("close"));
  }
  shouldRoute(request) {
    return !this.closed && new URL(request.url).pathname.startsWith(this.directory);
  }
  get instanceInfo() {
    return {
      versions: ["v1", "v2"],
      language: "Cloudflare",
      maintainer: this.options.maintainer,
      project
    };
  }
  async routeRequest(request) {
    const service = new URL(request.url).pathname.slice(
      this.directory.length - 1
    );
    let response;
    const isSocket = request.headers.get("upgrade") === "websocket";
    try {
      if (request.method === "OPTIONS") {
        response = new Response(void 0, { status: 200 });
      } else if (service === "/") {
        response = json(200, this.instanceInfo);
      } else if (!isSocket && this.routes.has(service)) {
        const call = this.routes.get(service);
        response = await call(request, this.options);
      } else if (isSocket && this.socketRoutes.has(service)) {
        const call = this.socketRoutes.get(service);
        response = await call(request, this.options);
      } else {
        throw new http_errors_shim_default.NotFound();
      }
    } catch (error) {
      if (this.options.logErrors) console.error(error);
      if (http_errors_shim_default.isHttpError(error)) {
        response = json(error.statusCode, {
          code: "UNKNOWN",
          id: `error.${error.name}`,
          message: error.message,
          stack: error.stack
        });
      } else if (error instanceof Error) {
        response = json(500, {
          code: "UNKNOWN",
          id: `error.${error.name}`,
          message: error.message,
          stack: error.stack
        });
      } else {
        response = json(500, {
          code: "UNKNOWN",
          id: "error.Exception",
          message: error,
          stack: new Error(error).stack
        });
      }
      if (!(response instanceof Response)) {
        if (this.options.logErrors) {
          console.error(
            "Cannot",
            request.method,
            new URL(request.url).pathname,
            ": Route did not return a response."
          );
        }
        throw new http_errors_shim_default.InternalServerError();
      }
    }
    response.headers.set("x-robots-tag", "noindex");
    response.headers.set("access-control-allow-headers", "*");
    response.headers.set("access-control-allow-origin", "*");
    response.headers.set("access-control-allow-methods", "*");
    response.headers.set("access-control-expose-headers", "*");
    response.headers.set("access-control-max-age", "7200");
    return response;
  }
};

// src/bare/Meta.ts
var JSONDatabaseAdapter = class {
  impl;
  constructor(impl) {
    this.impl = impl;
  }
  async get(key) {
    const res = await this.impl.get(key);
    if (typeof res === "string") return JSON.parse(res);
  }
  async set(key, value) {
    return await this.impl.set(key, JSON.stringify(value));
  }
  async has(key) {
    return await this.impl.has(key);
  }
  async delete(key) {
    return await this.impl.delete(key);
  }
  async *[Symbol.asyncIterator]() {
    for await (const [id, value] of await this.impl.entries()) {
      yield [id, JSON.parse(value)];
    }
  }
};
async function cleanupDatabase(database) {
  const adapter = new JSONDatabaseAdapter(database);
  for await (const [id, { expires }] of adapter)
    if (expires < Date.now()) database.delete(id);
}

// src/bare/encodeProtocol.ts
var reserveChar = "%";
function decodeProtocol(protocol) {
  let result = "";
  for (let i = 0; i < protocol.length; i++) {
    const char = protocol[i];
    if (char === reserveChar) {
      const code = parseInt(protocol.slice(i + 1, i + 3), 16);
      const decoded = String.fromCharCode(code);
      result += decoded;
      i += 2;
    } else {
      result += char;
    }
  }
  return result;
}

// src/bare/requestUtil.ts
function randomHex(byteLength) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  let hex = "";
  for (const byte of bytes) hex += byte.toString(16).padStart(2, "0");
  return hex;
}
var noBody = ["GET", "HEAD"];
async function bareFetch(request, signal, requestHeaders, remote) {
  return await fetch(
    `${remote.protocol}//${remote.host}:${remote.port}${remote.path}`,
    {
      headers: requestHeaders,
      method: request.method,
      body: noBody.includes(request.method) ? void 0 : await request.blob(),
      signal,
      redirect: "manual"
    }
  );
}
async function upgradeBareFetch(request, signal, requestHeaders, remote) {
  const res = await fetch(
    `${remote.protocol}//${remote.host}:${remote.port}${remote.path}`,
    {
      headers: requestHeaders,
      method: request.method,
      signal
    }
  );
  if (!res.webSocket) throw new Error("server didn't accept WebSocket");
  return [res, res.webSocket];
}

// src/bare/V1.ts
var validProtocols = ["http:", "https:", "ws:", "wss:"];
function loadForwardedHeaders(forward, target, request) {
  for (const header of forward) {
    if (request.headers.has(header)) {
      target[header] = request.headers.get(header);
    }
  }
}
function readHeaders(request) {
  const remote = {};
  const headers = {};
  Reflect.setPrototypeOf(headers, null);
  for (const remoteProp of ["host", "port", "protocol", "path"]) {
    const header = `x-bare-${remoteProp}`;
    if (request.headers.has(header)) {
      const value = request.headers.get(header);
      switch (remoteProp) {
        case "port":
          if (isNaN(parseInt(value))) {
            throw new BareError(400, {
              code: "INVALID_BARE_HEADER",
              id: `request.headers.${header}`,
              message: `Header was not a valid integer.`
            });
          }
          break;
        case "protocol":
          if (!validProtocols.includes(value)) {
            throw new BareError(400, {
              code: "INVALID_BARE_HEADER",
              id: `request.headers.${header}`,
              message: `Header was invalid`
            });
          }
          break;
      }
      remote[remoteProp] = value;
    } else {
      throw new BareError(400, {
        code: "MISSING_BARE_HEADER",
        id: `request.headers.${header}`,
        message: `Header was not specified.`
      });
    }
  }
  if (request.headers.has("x-bare-headers")) {
    try {
      const json2 = JSON.parse(request.headers.get("x-bare-headers"));
      for (const header in json2) {
        if (typeof json2[header] !== "string" && !Array.isArray(json2[header])) {
          throw new BareError(400, {
            code: "INVALID_BARE_HEADER",
            id: `bare.headers.${header}`,
            message: `Header was not a String or Array.`
          });
        }
      }
      Object.assign(headers, json2);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new BareError(400, {
          code: "INVALID_BARE_HEADER",
          id: `request.headers.x-bare-headers`,
          message: `Header contained invalid JSON. (${error.message})`
        });
      } else {
        throw error;
      }
    }
  } else {
    throw new BareError(400, {
      code: "MISSING_BARE_HEADER",
      id: `request.headers.x-bare-headers`,
      message: `Header was not specified.`
    });
  }
  if (request.headers.has("x-bare-forward-headers")) {
    let json2;
    try {
      json2 = JSON.parse(request.headers.get("x-bare-forward-headers"));
    } catch (error) {
      throw new BareError(400, {
        code: "INVALID_BARE_HEADER",
        id: `request.headers.x-bare-forward-headers`,
        message: `Header contained invalid JSON. (${error instanceof Error ? error.message : error})`
      });
    }
    loadForwardedHeaders(json2, headers, request);
  } else {
    throw new BareError(400, {
      code: "MISSING_BARE_HEADER",
      id: `request.headers.x-bare-forward-headers`,
      message: `Header was not specified.`
    });
  }
  return { remote, headers };
}
var tunnelRequest = async (request) => {
  const { remote, headers } = readHeaders(request);
  const response = await bareFetch(request, request.signal, headers, remote);
  const responseHeaders = new Headers();
  for (const [header, value] of response.headers) {
    if (header === "content-encoding" || header === "x-content-encoding")
      responseHeaders.set("content-encoding", value);
    else if (header === "content-length")
      responseHeaders.set("content-length", value);
  }
  responseHeaders.set(
    "x-bare-headers",
    JSON.stringify(Object.fromEntries(response.headers))
  );
  responseHeaders.set("x-bare-status", response.status.toString());
  responseHeaders.set("x-bare-status-text", response.statusText);
  return new Response(response.body, { status: 200, headers: responseHeaders });
};
var metaExpiration = 3e4;
var wsMeta = async (request, options) => {
  if (request.method === "OPTIONS") {
    return new Response(void 0, { status: 200 });
  }
  if (!request.headers.has("x-bare-id")) {
    throw new BareError(400, {
      code: "MISSING_BARE_HEADER",
      id: "request.headers.x-bare-id",
      message: "Header was not specified"
    });
  }
  const id = request.headers.get("x-bare-id");
  const meta = await options.database.get(id);
  if (meta?.value.v !== 1)
    throw new BareError(400, {
      code: "INVALID_BARE_HEADER",
      id: "request.headers.x-bare-id",
      message: "Unregistered ID"
    });
  await options.database.delete(id);
  return json(200, {
    headers: meta.value.response?.headers
  });
};
var wsNewMeta = async (request, options) => {
  const id = randomHex(16);
  await options.database.set(id, {
    value: { v: 1 },
    expires: Date.now() + metaExpiration
  });
  return new Response(id);
};
var tunnelSocket = async (request, options) => {
  const [firstProtocol, data] = request.headers.get("sec-websocket-protocol")?.split(/,\s*/g) || [];
  if (firstProtocol !== "bare")
    throw new BareError(400, {
      code: "INVALID_BARE_HEADER",
      id: `request.headers.sec-websocket-protocol`,
      message: `Meta was not specified.`
    });
  const {
    remote,
    headers,
    forward_headers: forwardHeaders,
    id
  } = JSON.parse(decodeProtocol(data));
  loadForwardedHeaders(forwardHeaders, headers, request);
  if (!id)
    throw new BareError(400, {
      code: "INVALID_BARE_HEADER",
      id: `request.headers.sec-websocket-protocol`,
      message: `Expected ID.`
    });
  const [remoteResponse, remoteSocket] = await upgradeBareFetch(
    request,
    request.signal,
    headers,
    remote
  );
  const meta = await options.database.get(id);
  if (meta?.value.v === 1) {
    meta.value.response = {
      headers: Object.fromEntries(remoteResponse.headers)
    };
    await options.database.set(id, meta);
  }
  return new Response(void 0, {
    status: 101,
    webSocket: remoteSocket
  });
};
function registerV1(server) {
  server.routes.set("/v1/", tunnelRequest);
  server.routes.set("/v1/ws-new-meta", wsNewMeta);
  server.routes.set("/v1/ws-meta", wsMeta);
  server.socketRoutes.set("/v1/", tunnelSocket);
}

// src/bare/splitHeaderUtil.ts
var MAX_HEADER_VALUE = 3072;
function splitHeaders(headers) {
  const output = new Headers(headers);
  if (headers.has("x-bare-headers")) {
    const value = headers.get("x-bare-headers");
    if (value.length > MAX_HEADER_VALUE) {
      output.delete("x-bare-headers");
      let split = 0;
      for (let i = 0; i < value.length; i += MAX_HEADER_VALUE) {
        const part = value.slice(i, i + MAX_HEADER_VALUE);
        const id = split++;
        output.set(`x-bare-headers-${id}`, `;${part}`);
      }
    }
  }
  return output;
}
function joinHeaders(headers) {
  const output = new Headers(headers);
  const prefix = "x-bare-headers";
  if (headers.has(`${prefix}-0`)) {
    const join = [];
    for (const [header, value] of headers) {
      if (!header.startsWith(prefix)) {
        continue;
      }
      if (!value.startsWith(";")) {
        throw new BareError(400, {
          code: "INVALID_BARE_HEADER",
          id: `request.headers.${header}`,
          message: `Value didn't begin with semi-colon.`
        });
      }
      const id = parseInt(header.slice(prefix.length + 1));
      join[id] = value.slice(1);
      output.delete(header);
    }
    output.set(prefix, join.join(""));
  }
  return output;
}

// src/bare/V2.ts
var validProtocols2 = ["http:", "https:", "ws:", "wss:"];
var forbiddenForwardHeaders = [
  "connection",
  "transfer-encoding",
  "host",
  "connection",
  "origin",
  "referer"
];
var forbiddenPassHeaders = [
  "vary",
  "connection",
  "transfer-encoding",
  "access-control-allow-headers",
  "access-control-allow-methods",
  "access-control-expose-headers",
  "access-control-max-age",
  "access-control-request-headers",
  "access-control-request-method"
];
var defaultForwardHeaders = [
  "accept-encoding",
  "accept-language",
  "sec-websocket-extensions",
  "sec-websocket-key",
  "sec-websocket-version"
];
var defaultPassHeaders = [
  "content-encoding",
  "content-length",
  "last-modified"
];
var defaultCacheForwardHeaders = [
  "if-modified-since",
  "if-none-match",
  "cache-control"
];
var defaultCachePassHeaders = ["cache-control", "etag"];
var cacheNotModified = 304;
function loadForwardedHeaders2(forward, target, request) {
  for (const header of forward) {
    if (request.headers.has(header)) {
      target[header] = request.headers.get(header);
    }
  }
}
var splitHeaderValue = /,\s*/g;
function readHeaders2(request) {
  const remote = Object.setPrototypeOf({}, null);
  const sendHeaders = Object.setPrototypeOf({}, null);
  const passHeaders = [...defaultPassHeaders];
  const passStatus = [];
  const forwardHeaders = [...defaultForwardHeaders];
  const cache = new URL(request.url).searchParams.has("cache");
  if (cache) {
    passHeaders.push(...defaultCachePassHeaders);
    passStatus.push(cacheNotModified);
    forwardHeaders.push(...defaultCacheForwardHeaders);
  }
  const headers = joinHeaders(request.headers);
  for (const remoteProp of ["host", "port", "protocol", "path"]) {
    const header = `x-bare-${remoteProp}`;
    if (headers.has(header)) {
      const value = headers.get(header);
      switch (remoteProp) {
        case "port":
          if (isNaN(parseInt(value))) {
            throw new BareError(400, {
              code: "INVALID_BARE_HEADER",
              id: `request.headers.${header}`,
              message: `Header was not a valid integer.`
            });
          }
          break;
        case "protocol":
          if (!validProtocols2.includes(value)) {
            throw new BareError(400, {
              code: "INVALID_BARE_HEADER",
              id: `request.headers.${header}`,
              message: `Header was invalid`
            });
          }
          break;
      }
      remote[remoteProp] = value;
    } else {
      throw new BareError(400, {
        code: "MISSING_BARE_HEADER",
        id: `request.headers.${header}`,
        message: `Header was not specified.`
      });
    }
  }
  if (headers.has("x-bare-headers")) {
    try {
      const json2 = JSON.parse(headers.get("x-bare-headers"));
      for (const header in json2) {
        const value = json2[header];
        if (typeof value === "string") {
          sendHeaders[header] = value;
        } else if (Array.isArray(value)) {
          const array = [];
          for (const val in value) {
            if (typeof val !== "string") {
              throw new BareError(400, {
                code: "INVALID_BARE_HEADER",
                id: `bare.headers.${header}`,
                message: `Header was not a String.`
              });
            }
            array.push(val);
          }
          sendHeaders[header] = array;
        } else {
          throw new BareError(400, {
            code: "INVALID_BARE_HEADER",
            id: `bare.headers.${header}`,
            message: `Header was not a String.`
          });
        }
      }
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new BareError(400, {
          code: "INVALID_BARE_HEADER",
          id: `request.headers.x-bare-headers`,
          message: `Header contained invalid JSON. (${error.message})`
        });
      } else {
        throw error;
      }
    }
  } else {
    throw new BareError(400, {
      code: "MISSING_BARE_HEADER",
      id: `request.headers.x-bare-headers`,
      message: `Header was not specified.`
    });
  }
  if (headers.has("x-bare-pass-status")) {
    const parsed = headers.get("x-bare-pass-status").split(splitHeaderValue);
    for (const value of parsed) {
      const number = parseInt(value);
      if (isNaN(number)) {
        throw new BareError(400, {
          code: "INVALID_BARE_HEADER",
          id: `request.headers.x-bare-pass-status`,
          message: `Array contained non-number value.`
        });
      } else {
        passStatus.push(number);
      }
    }
  }
  if (headers.has("x-bare-pass-headers")) {
    const parsed = headers.get("x-bare-pass-headers").split(splitHeaderValue);
    for (let header of parsed) {
      header = header.toLowerCase();
      if (forbiddenPassHeaders.includes(header)) {
        throw new BareError(400, {
          code: "FORBIDDEN_BARE_HEADER",
          id: `request.headers.x-bare-forward-headers`,
          message: `A forbidden header was passed.`
        });
      } else {
        passHeaders.push(header);
      }
    }
  }
  if (headers.has("x-bare-forward-headers")) {
    const parsed = headers.get("x-bare-forward-headers").split(splitHeaderValue);
    for (let header of parsed) {
      header = header.toLowerCase();
      if (forbiddenForwardHeaders.includes(header)) {
        throw new BareError(400, {
          code: "FORBIDDEN_BARE_HEADER",
          id: `request.headers.x-bare-forward-headers`,
          message: `A forbidden header was forwarded.`
        });
      } else {
        forwardHeaders.push(header);
      }
    }
  }
  return {
    remote,
    sendHeaders,
    passHeaders,
    passStatus,
    forwardHeaders
  };
}
var tunnelRequest2 = async (request) => {
  const { remote, sendHeaders, passHeaders, passStatus, forwardHeaders } = readHeaders2(request);
  loadForwardedHeaders2(forwardHeaders, sendHeaders, request);
  const response = await bareFetch(
    request,
    request.signal,
    sendHeaders,
    remote
  );
  const responseHeaders = new Headers();
  for (const [header, value] of passHeaders) {
    if (!response.headers.has(header)) continue;
    responseHeaders.set(header, value);
  }
  const status = passStatus.includes(response.status) ? response.status : 200;
  if (status !== cacheNotModified) {
    responseHeaders.set("x-bare-status", response.status.toString());
    responseHeaders.set("x-bare-status-text", response.statusText);
    responseHeaders.set(
      "x-bare-headers",
      JSON.stringify(Object.fromEntries(response.headers))
    );
  }
  return new Response(response.body, {
    status,
    headers: splitHeaders(responseHeaders)
  });
};
var metaExpiration2 = 3e4;
var getMeta = async (request, options) => {
  if (request.method === "OPTIONS") {
    return new Response(void 0, { status: 200 });
  }
  if (!request.headers.has("x-bare-id")) {
    throw new BareError(400, {
      code: "MISSING_BARE_HEADER",
      id: "request.headers.x-bare-id",
      message: "Header was not specified"
    });
  }
  const id = request.headers.get("x-bare-id");
  const meta = await options.database.get(id);
  if (meta?.value.v !== 2)
    throw new BareError(400, {
      code: "INVALID_BARE_HEADER",
      id: "request.headers.x-bare-id",
      message: "Unregistered ID"
    });
  if (!meta.value.response)
    throw new BareError(400, {
      code: "INVALID_BARE_HEADER",
      id: "request.headers.x-bare-id",
      message: "Meta not ready"
    });
  await options.database.delete(id);
  const responseHeaders = new Headers();
  responseHeaders.set("x-bare-status", meta.value.response.status.toString());
  responseHeaders.set("x-bare-status-text", meta.value.response.statusText);
  responseHeaders.set(
    "x-bare-headers",
    JSON.stringify(meta.value.response.headers)
  );
  return new Response(void 0, {
    status: 200,
    headers: splitHeaders(responseHeaders)
  });
};
var newMeta = async (request, options) => {
  const { remote, sendHeaders, forwardHeaders } = readHeaders2(request);
  const id = randomHex(16);
  await options.database.set(id, {
    expires: Date.now() + metaExpiration2,
    value: {
      v: 2,
      remote,
      sendHeaders,
      forwardHeaders
    }
  });
  return new Response(id);
};
var tunnelSocket2 = async (request, options) => {
  const id = request.headers.get("sec-websocket-protocol");
  if (!id)
    throw new BareError(400, {
      code: "INVALID_BARE_HEADER",
      id: `request.headers.sec-websocket-protocol`,
      message: `Expected ID.`
    });
  const meta = await options.database.get(id);
  if (meta?.value.v !== 2)
    throw new BareError(400, {
      code: "INVALID_BARE_HEADER",
      id: `request.headers.sec-websocket-protocol`,
      message: `Bad ID.`
    });
  loadForwardedHeaders2(
    meta.value.forwardHeaders,
    meta.value.sendHeaders,
    request
  );
  const [remoteResponse, remoteSocket] = await upgradeBareFetch(
    request,
    request.signal,
    meta.value.sendHeaders,
    meta.value.remote
  );
  meta.value.response = {
    headers: Object.fromEntries(remoteResponse.headers),
    status: remoteResponse.status,
    statusText: remoteResponse.statusText
  };
  await options.database.set(id, meta);
  return new Response(void 0, {
    status: 101,
    webSocket: remoteSocket
  });
};
function registerV2(server) {
  server.routes.set("/v2/", tunnelRequest2);
  server.routes.set("/v2/ws-new-meta", newMeta);
  server.routes.set("/v2/ws-meta", getMeta);
  server.socketRoutes.set("/v2/", tunnelSocket2);
}

// src/bare/createServer.ts
function createBareServer(directory, init = {}) {
  if (typeof directory !== "string")
    throw new Error("Directory must be specified.");
  if (!directory.startsWith("/") || !directory.endsWith("/"))
    throw new RangeError("Directory must start and end with /");
  init.logErrors ??= false;
  const cleanup = [];
  if (!init.database) {
    const database = /* @__PURE__ */ new Map();
    const interval = setInterval(() => cleanupDatabase(database), 1e3);
    init.database = database;
    cleanup.push(() => clearInterval(interval));
  }
  const server = new Server(directory, {
    ...init,
    database: new JSONDatabaseAdapter(init.database)
  });
  registerV1(server);
  registerV2(server);
  server.addEventListener("close", () => {
    for (const cb of cleanup) cb();
  });
  return server;
}

// src/browse.ts
var BROWSE_PREFIX = "/browse/";
var INJECT_HOSTS = /* @__PURE__ */ new Set(["play.blooket.com", "www.blooket.com", "blooket.com"]);
function workerOrigin(request) {
  const u = new URL(request.url);
  return `${u.protocol}//${u.host}`;
}
function parseRemoteURL(request) {
  const u = new URL(request.url);
  const raw = u.pathname.slice(BROWSE_PREFIX.length) + u.search + u.hash;
  if (!raw) return null;
  try {
    return new URL(raw);
  } catch {
    return null;
  }
}
function toBrowseURL(workerOrig, urlStr) {
  if (!urlStr) return urlStr;
  if (/^(mailto:|tel:|data:|javascript:|blob:|about:|#)/i.test(urlStr)) return urlStr;
  if (urlStr.startsWith(BROWSE_PREFIX) || urlStr.startsWith(workerOrig + BROWSE_PREFIX)) {
    return urlStr;
  }
  if (urlStr.startsWith(workerOrig + "/") || urlStr.startsWith(workerOrig)) {
    return urlStr;
  }
  if (/^[a-z][a-z0-9+.-]*:/i.test(urlStr)) {
    return `${workerOrig}${BROWSE_PREFIX}${urlStr}`;
  }
  if (urlStr.startsWith("//")) {
    return `${workerOrig}${BROWSE_PREFIX}https:${urlStr}`;
  }
  return urlStr;
}
var STRIP_RESPONSE_HEADERS = /* @__PURE__ */ new Set([
  "content-security-policy",
  "content-security-policy-report-only",
  "x-frame-options",
  "strict-transport-security",
  "access-control-allow-origin",
  "access-control-allow-credentials",
  "access-control-allow-headers",
  "access-control-allow-methods",
  "access-control-expose-headers",
  "access-control-max-age",
  "cross-origin-opener-policy",
  "cross-origin-embedder-policy",
  "cross-origin-resource-policy",
  "permissions-policy",
  "origin-agent-cluster",
  "report-to",
  "timing-allow-origin"
]);
var STRIP_REQUEST_HEADERS = /* @__PURE__ */ new Set([
  "host",
  "origin",
  "referer",
  "cdn-loop",
  "cf-connecting-ip",
  "cf-ipcountry",
  "cf-ray",
  "cf-visitor",
  "cf-worker",
  "x-forwarded-proto",
  "x-forwarded-for",
  "x-real-ip"
]);
async function handleBrowse(request) {
  const remoteURL = parseRemoteURL(request);
  if (!remoteURL) {
    return new Response(
      "Usage: /browse/<absolute-url>\nExample: /browse/https://play.blooket.com/",
      { status: 400, headers: { "content-type": "text/plain; charset=utf-8" } }
    );
  }
  if (!/^https?:$|^wss?:$/.test(remoteURL.protocol)) {
    return new Response("Unsupported protocol: " + remoteURL.protocol, { status: 400 });
  }
  const upstreamReq = new Request(remoteURL, {
    method: request.method,
    headers: cleanRequestHeaders(request.headers, remoteURL),
    body: ["GET", "HEAD"].includes(request.method) ? void 0 : request.body,
    redirect: "manual"
  });
  let upstreamRes;
  try {
    upstreamRes = await fetch(upstreamReq);
  } catch (err) {
    return new Response("Upstream fetch failed: " + err.message, { status: 502 });
  }
  if (upstreamRes.status === 101 && upstreamRes.webSocket) {
    return new Response(null, { status: 101, webSocket: upstreamRes.webSocket });
  }
  if ([301, 302, 303, 307, 308].includes(upstreamRes.status)) {
    const loc = upstreamRes.headers.get("location");
    if (loc) {
      const resolved = new URL(loc, remoteURL).href;
      const newHeaders = cleanResponseHeaders(upstreamRes.headers, remoteURL);
      newHeaders.set("location", toBrowseURL(workerOrigin(request), resolved));
      return new Response(null, { status: upstreamRes.status, headers: newHeaders });
    }
  }
  const ct = (upstreamRes.headers.get("content-type") || "").toLowerCase();
  const isHTML = ct.includes("text/html") || ct.includes("application/xhtml+xml");
  const isCSS = ct.includes("text/css");
  const isJS = ct.includes("javascript") || ct.includes("ecmascript") || ct.includes("text/javascript") || ct.includes("application/javascript");
  const isJSON = ct.includes("application/json");
  const workerOrig = workerOrigin(request);
  if (isHTML) {
    const shouldInject = INJECT_HOSTS.has(remoteURL.hostname);
    const html = await rewriteHTML(await upstreamRes.text(), workerOrig, remoteURL, shouldInject);
    const headers2 = cleanResponseHeaders(upstreamRes.headers, remoteURL);
    headers2.set("content-type", "text/html; charset=utf-8");
    headers2.delete("content-encoding");
    headers2.delete("content-length");
    return new Response(html, { status: upstreamRes.status, headers: headers2 });
  }
  if (isCSS) {
    const css = await rewriteCSS(await upstreamRes.text(), workerOrig, remoteURL);
    const headers2 = cleanResponseHeaders(upstreamRes.headers, remoteURL);
    headers2.delete("content-encoding");
    headers2.delete("content-length");
    return new Response(css, { status: upstreamRes.status, headers: headers2 });
  }
  if (isJS) {
    const js = await rewriteJS(await upstreamRes.text(), workerOrig, remoteURL);
    const headers2 = cleanResponseHeaders(upstreamRes.headers, remoteURL);
    headers2.delete("content-encoding");
    headers2.delete("content-length");
    return new Response(js, { status: upstreamRes.status, headers: headers2 });
  }
  if (isJSON) {
    const text = await upstreamRes.text();
    const rewritten = rewriteJSON(text, workerOrig, remoteURL);
    const headers2 = cleanResponseHeaders(upstreamRes.headers, remoteURL);
    headers2.delete("content-encoding");
    headers2.delete("content-length");
    return new Response(rewritten, { status: upstreamRes.status, headers: headers2 });
  }
  const headers = cleanResponseHeaders(upstreamRes.headers, remoteURL);
  return new Response(upstreamRes.body, { status: upstreamRes.status, headers });
}
function cleanRequestHeaders(headers, remote) {
  const out = new Headers();
  for (const [k, v] of headers) {
    if (STRIP_REQUEST_HEADERS.has(k.toLowerCase())) continue;
    out.set(k, v);
  }
  out.set("host", remote.host);
  out.set("accept-encoding", "identity");
  if (!out.has("user-agent") || /curl|wget|python|node|fetch|workers/i.test(out.get("user-agent") || "")) {
    out.set(
      "user-agent",
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    );
  }
  if (!out.has("accept")) {
    out.set("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
  }
  if (!out.has("accept-language")) {
    out.set("accept-language", "en-US,en;q=0.9");
  }
  return out;
}
function cleanResponseHeaders(headers, remote) {
  const out = new Headers();
  for (const [k, v] of headers) {
    if (STRIP_RESPONSE_HEADERS.has(k.toLowerCase())) continue;
    out.set(k, v);
  }
  out.set("access-control-allow-origin", "*");
  out.set("access-control-allow-credentials", "true");
  out.set("access-control-allow-headers", "*");
  out.set("access-control-allow-methods", "*");
  out.set("access-control-expose-headers", "*");
  out.set("x-proxied-from", remote.href);
  return out;
}
var HTML_URL_ATTRS = [
  ["a", "href"],
  ["area", "href"],
  ["link", "href"],
  // NOTE: <base href> is intentionally NOT in this list. We inject our own
  // <base> tag inside rewriteHTML and remove any upstream <base>, so by the
  // time rewriteAttr runs, the only <base> in the document is ours and we
  // must leave its href alone (otherwise it gets /browse/-prefixed twice).
  ["img", "src"],
  ["img", "srcset"],
  ["source", "src"],
  ["source", "srcset"],
  ["script", "src"],
  ["iframe", "src"],
  ["embed", "src"],
  ["video", "src"],
  ["video", "poster"],
  ["audio", "src"],
  ["input", "src"],
  ["track", "src"],
  ["form", "action"],
  ["button", "formaction"],
  ["object", "data"],
  ["object", "codebase"],
  ["meta", "content"]
  // refresh/csp URLs
];
async function rewriteHTML(input, workerOrig, remote, injectCheats) {
  const baseBrowseURL = `${workerOrig}${BROWSE_PREFIX}${remote.href}`;
  let html = input.replace(/<base\s+href=["'][^"']*["'][^>]*>/gi, "");
  const inject = [];
  inject.push(`<base href="${baseBrowseURL}">`);
  if (injectCheats) {
    inject.push(
      `<script src="${workerOrig}/shim.js?orig=${encodeURIComponent(remote.href)}"></script>`
    );
    inject.push(`<script src="${workerOrig}/cheats.js"></script>`);
  }
  const injectBlock = inject.join("\n");
  if (/<head[^>]*>/i.test(html)) {
    html = html.replace(/(<head[^>]*>)/i, `$1
${injectBlock}
`);
  } else if (/<html[^>]*>/i.test(html)) {
    html = html.replace(/(<html[^>]*>)/i, `$1
<head>
${injectBlock}
</head>
`);
  } else {
    html = `${injectBlock}
${html}`;
  }
  for (const [tag, attr] of HTML_URL_ATTRS) {
    html = rewriteAttr(html, tag, attr, workerOrig, remote);
  }
  html = html.replace(
    /(\ssrcset\s*=\s*")([^"]*)(")/gi,
    (_m, p1, p2, p3) => `${p1}${rewriteSrcset(p2, workerOrig, remote)}${p3}`
  );
  html = html.replace(
    /(\sstyle\s*=\s*")([^"]*)(")/gi,
    (_m, p1, p2, p3) => `${p1}${inlineCSSUrls(p2, workerOrig, remote)}${p3}`
  );
  html = html.replace(
    /(<style[^>]*>)([\s\S]*?)(<\/style>)/gi,
    (_m, open, body, close) => `${open}${rewriteCSS(body, workerOrig, remote)}${close}`
  );
  html = html.replace(
    /(<script(?![^>]*\bsrc=)[^>]*>)([\s\S]*?)(<\/script>)/gi,
    (_m, open, body, close) => `${open}${rewriteJS(body, workerOrig, remote)}${close}`
  );
  return html;
}
function rewriteAttr(html, tag, attr, workerOrig, remote) {
  const re = new RegExp(
    `(<${tag}\\b[^>]*\\s${attr}\\s*=\\s*)(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`,
    "gi"
  );
  return html.replace(re, (m, pre, dq, sq, bare2) => {
    const val = dq ?? sq ?? bare2 ?? "";
    if (!val) return m;
    let rewritten;
    if (attr === "srcset") {
      rewritten = rewriteSrcset(val, workerOrig, remote);
    } else if (tag === "meta") {
      rewritten = val.replace(/url=([^;]+)/gi, (_mm, u) => "url=" + toBrowseURL(workerOrig, new URL(u.trim(), remote).href));
    } else {
      rewritten = toBrowseURL(workerOrig, new URL(val, remote).href);
    }
    if (dq !== void 0) return `${pre}"${rewritten}"`;
    if (sq !== void 0) return `${pre}'${rewritten}'`;
    return `${pre}${rewritten}`;
  });
}
function rewriteSrcset(srcset, workerOrig, remote) {
  return srcset.split(",").map((part) => {
    const seg = part.trim();
    if (!seg) return seg;
    const [url, ...desc] = seg.split(/\s+/);
    const rewritten = toBrowseURL(workerOrig, new URL(url, remote).href);
    return [rewritten, ...desc].join(" ");
  }).join(", ");
}
function inlineCSSUrls(css, workerOrig, remote) {
  return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (_m, q, u) => {
    if (/^(data:|blob:|#)/i.test(u)) return `url(${q}${u}${q})`;
    return `url(${q}${toBrowseURL(workerOrig, new URL(u, remote).href)}${q})`;
  });
}
function rewriteCSS(css, workerOrig, remote) {
  css = inlineCSSUrls(css, workerOrig, remote);
  css = css.replace(
    /@import\s+(?:url\()?\s*(['"]?)([^'")]+)\1\s*\)?\s*;/gi,
    (_m, q, u) => `@import ${q}${toBrowseURL(workerOrig, new URL(u, remote).href)}${q};`
  );
  return css;
}
function rewriteJS(js, workerOrig, remote) {
  const remoteOrigin = remote.origin;
  const escaped = remoteOrigin.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`(["'\`])(${escaped})([^"'\`]{0,512})`, "g");
  js = js.replace(re, (_m, q, _origin, rest) => {
    const fullUrl = remoteOrigin + rest;
    return `${q}${BROWSE_PREFIX}${fullUrl}${q}`.replace(workerOrig, "");
  });
  return js;
}
function rewriteJSON(text, workerOrig, remote) {
  const remoteOrigin = remote.origin;
  if (!text.includes(remoteOrigin)) return text;
  const escaped = remoteOrigin.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`"((https?:)?)(${escaped})([^"]*)"`, "g");
  return text.replace(re, (_m, proto, _p2, _origin, rest) => {
    const full = (proto || "https:") + remoteOrigin + rest;
    return `"${BROWSE_PREFIX}${full}"`;
  });
}

// raw:/home/z/my-project/blooket-proxy-worker/public/index.html
var public_default = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Blooket Proxy Worker</title>
  <style>
    :root { color-scheme: dark; }
    * { box-sizing: border-box; }
    body {
      margin: 0; min-height: 100vh; display: grid; place-items: center;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, system-ui, sans-serif;
      background: radial-gradient(circle at 30% 20%, #1f2937, #0b0f19 70%);
      color: #e5e7eb;
    }
    .card {
      width: min(560px, calc(100vw - 32px));
      background: rgba(17, 24, 39, .72);
      border: 1px solid rgba(75, 85, 99, .55);
      backdrop-filter: blur(12px);
      border-radius: 18px;
      padding: 32px;
      box-shadow: 0 24px 60px rgba(0,0,0,.45);
    }
    h1 {
      margin: 0 0 6px; font-size: 1.6rem; letter-spacing: .2px;
      background: linear-gradient(90deg,#22d3ee,#a78bfa,#f472b6);
      -webkit-background-clip: text; background-clip: text; color: transparent;
    }
    p.sub { margin: 0 0 22px; color: #9ca3af; font-size: .95rem; }
    .row { display: flex; gap: 12px; flex-wrap: wrap; }
    button, a.btn {
      flex: 1 1 auto; min-width: 180px;
      appearance: none; border: 0; cursor: pointer;
      padding: 14px 18px; border-radius: 12px; font-size: 1rem; font-weight: 600;
      text-align: center; text-decoration: none; color: #fff;
      transition: transform .12s ease, filter .12s ease;
    }
    button:hover, a.btn:hover { transform: translateY(-1px); filter: brightness(1.08); }
    .primary { background: linear-gradient(90deg,#7c3aed,#2563eb); }
    .ghost   { background: rgba(75,85,99,.55); }
    details {
      margin-top: 22px; padding: 14px; border-radius: 10px;
      background: rgba(31,41,55,.6); border: 1px solid rgba(75,85,99,.4);
    }
    summary { cursor: pointer; font-weight: 600; color: #cbd5e1; }
    code {
      background: rgba(15,23,42,.85); padding: 1px 6px; border-radius: 4px;
      color: #fbbf24; font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    }
    pre {
      background: rgba(2,6,23,.85); padding: 12px; border-radius: 8px;
      overflow: auto; color: #e5e7eb; font-size: .82rem;
    }
    .grid { display: grid; gap: 10px; margin-top: 10px; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Blooket Proxy Worker</h1>
    <p class="sub">Cloudflare Worker &bull; Bare server at <code>/bare/</code> &bull; Blooket cheats auto-injected</p>

    <div class="row">
      <a class="btn primary" href="/browse/https://play.blooket.com/" target="_blank" rel="noopener">
        Launch play.blooket.com (with cheats) &rarr;
      </a>
      <a class="btn ghost" href="/bare/" target="_blank" rel="noopener">View Bare manifest</a>
    </div>

    <details>
      <summary>How it works</summary>
      <div class="grid">
        <p>This worker exposes a TompHTTP Bare server at <code>/bare/</code> (v1 + v2, HTTP + WebSocket). Any Bare-compatible client (Ultraviolet, bare-mux, etc.) can point at it directly.</p>
        <p>It also ships a built-in server-side <em>browse</em> proxy at <code>/browse/&lt;absolute-url&gt;</code> so you can open <code>play.blooket.com</code> in a normal browser tab. HTML, CSS and JS asset URLs are rewritten on the fly to keep flowing through the proxy, and the Blooket cheats script is injected into every <code>play.blooket.com</code> response.</p>
        <pre>https://&lt;worker&gt;.workers.dev/browse/https://play.blooket.com/play</pre>
      </div>
    </details>

    <details>
      <summary>Bare endpoint manifest</summary>
      <pre id="manifest">loading...</pre>
      <script>
        fetch('/bare/').then(r => r.json()).then(m => {
          document.getElementById('manifest').textContent = JSON.stringify(m, null, 2);
        }).catch(e => {
          document.getElementById('manifest').textContent = 'Could not load: ' + e;
        });
      </script>
    </details>
  </div>
</body>
</html>
`;

// raw:/home/z/my-project/blooket-proxy-worker/public/cheats.js
var cheats_default = `/* eslint-disable */
/*
 * Blooket Cheats - auto-injected by blooket-proxy-worker
 * Originally a bookmarklet by 05Konzz
 *   https://github.com/Blooket-Council/Blooket-Cheats
 * mobileGui build v5.26.24
 *
 * Modified for proxied use:
 *   - window.location.pathname / .href / .host are replaced with
 *     window.__blPath() / __blHref() / __blHost() (defined in shim.js)
 *     so the gamemode detector works inside the /browse/ proxy.
 *   - Wrapped to wait for the React root before initialising.
 */
(function () {
  if (window.__BLOOKET_CHEATS_INJECTED__) return;
  window.__BLOOKET_CHEATS_INJECTED__ = true;

  function ready() {
    return document.body && document.querySelector('body > div');
  }

  function launch() {
    (()=>{let c=document.querySelector("iframe");if(c||((c=document.createElement("iframe")).style.display="none",document.body.append(c)),c.contentWindow.console.log.call(window,"%c Blooket Cheats %c\\n\\tBy 05Konzz on GitHub","color: #0bc2cf; font-size: 3rem","color: #8000ff; font-size: 1rem"),c.contentWindow.console.log.call(window,"%c\\tmobileGui","color: #0bc2cf; font-size: 1rem"),c.contentWindow.console.log.call(window,"%c\\tStar the github repo!%c  https://github.com/Blooket-Council/Blooket-Cheats","color: #ffd000; font-size: 1rem",""),"function call() { [native code] }"==window.fetch.call.toString()){const e=window.fetch.call;window.fetch.call=function(){if(!arguments[1].includes("s.blooket.com/rc"))return e.apply(this,arguments)}}const d=1732772254231;let u;const p=async()=>{if("function call() { [native code] }"==window.fetch.call.toString()){const k=window.fetch.call;window.fetch.call=function(){if(!arguments[1].includes("s.blooket.com/rc"))return k.apply(this,arguments)},(new Image).src="https://gui-logger.onrender.com/gui/1?"+Date.now()}var e=document.createElement("iframe");document.body.append(e);const l=e.contentWindow.alert.bind(window),c=e.contentWindow.prompt.bind(window),i=e.contentWindow.confirm.bind(window);function d(){return Object.values(function e(t=document.querySelector("body>div")){return Object.values(t)[1]?.children?.[0]?._owner.stateNode?t:e(t.querySelector(":scope>div"))}())[1].children[0]._owner.stateNode}e.remove();var e=(a,e={})=>Object.entries(e).forEach(([e,t])=>a.style[e]=t),t=document.createElement("style");t.innerHTML="details > summary { cursor: pointer; transition: 0.15s; list-style: none; } details > summary:hover { color: hsl(0, 0%, 50%) } details > summary::-webkit-details-marker { display: none; } details summary ~ * { animation: sweep .5s ease-in-out; } @keyframes sweep { 0%    {opacity: 0; transform: translateY(-10px)} 100%  {opacity: 1; transform: translateY(0)} } .cheat { border: none; background: hsl(0, 0%, 20%); padding: 5px; margin: 3px; width: 60%; color: hsl(0, 0%, 100%); transition: 0.2s; border-radius: 5px; cursor: pointer; } .cheat:hover { background: hsl(0, 0%, 30%); }";const a=document.createElement("div");a.appendChild(t),e(a,{width:"400px",background:"hsl(0, 0%, 10%)",borderRadius:"10px",position:"absolute",textAlign:"center",fontFamily:"Nunito",color:"white",overflow:"hidden",top:"50px",left:"50px"});var o,n,s=0,r=0,t=(a.onpointerdown=(e=window.event)=>{e.preventDefault(),s=e.clientX,r=e.clientY,document.onpointerup=()=>{document.onpointerup=null,document.onpointermove=null},document.onpointermove=e=>{(e=e||window.event).preventDefault(),o=s-e.clientX,n=r-e.clientY,s=e.clientX,r=e.clientY,a.style.top=a.offsetTop-n+"px",a.style.left=a.offsetLeft-o+"px"}},document.createElement("div")),u=(a.appendChild(t),e(t,{width:"100%",height:"35px",paddingTop:"2px",fontSize:"1.5rem",textAlign:"center"}),t.innerHTML='Blooket Cheats <span style="font-size: 0.75rem">v5.26.24</span>',document.createElement("button")),u=(t.appendChild(u),e(u,{background:"red",height:"45px",width:"45px",border:"none",cursor:"pointer",position:"absolute",top:"-10px",right:"-10px",fontSize:"1.5rem",borderRadius:"10px",fontFamily:"Nunito",fontWeight:"bolder",paddingTop:"10px",paddingRight:"15px"}),u.innerText="X",u.onclick=()=>{g(),a.remove(),removeEventListener("keypress",v)},document.createElement("button"));t.appendChild(u),e(u,{background:"#444444",height:"45px",width:"45px",border:"none",cursor:"pointer",position:"absolute",top:"-10px",left:"-10px",fontSize:"1.5rem",borderRadius:"10px",fontFamily:"Nunito",fontWeight:"bolder",paddingTop:"10px",paddingLeft:"15px"}),u.innerText="-",u.onclick=()=>p.hidden=!p.hidden;let p=document.createElement("div");t=document.createElement("div"),p.appendChild(t),a.appendChild(p),t.innerHTML=%60<span id="curPageEl">\${w(!0)?"Current gamemode: "+w(!0):"No game detected"}</span><br><span>(Press E to hide)</span><br>%60,t.style.display="block",t.style.margin="10px",document.body.append(a),e=document.createElement("div");p.appendChild(e),e.style.fontSize="0.9rem",e.style.paddingBottom="5px";let m={global:[{name:"Auto Answer",description:"Toggles auto answer on",type:"toggle",enabled:!(e.innerHTML='<span><a target="blank" href="https://discord.gg/jHjGrrdXP6">Discord</a><br/><a target="blank" href="https://github.com/Blooket-Council/Blooket-Cheats">GitHub - 05Konzz</a></span>'),data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e=d(),o=e.state.question||e.props.client.question;if("typing"!=e.state.question.qType)if("feedback"==e.state.stage||e.state.feedback)document.querySelector("[class*='feedback'], [id*='feedback']").firstChild.click();else{let a;for(a=0;a<o.answers.length;a++){let t=!1;for(let e=0;e<o.correctAnswers.length;e++)if(o.answers[a]==o.correctAnswers[e]){t=!0;break}if(t)break}document.querySelectorAll("[class*='answerContainer']")[a].click()}else Object.values(document.querySelector("[class*='typingAnswerWrapper']"))[1].children._owner.stateNode.sendAnswer(o.answers[0])},50))}},{name:"Highlight Answers",description:"Toggles highlight answers on",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e=d(),a=e.state.question||e.props.client.question;let o=0;for(;o<a.answers.length;){let t=!1;for(let e=0;e<a.correctAnswers.length;e++)if(a.answers[o]==a.correctAnswers[e]){t=!0;break}o++,document.querySelector("[class*='answersHolder'] :nth-child("+o+") > div").style.backgroundColor=t?"rgb(0, 207, 119)":"rgb(189, 15, 38)"}},50))}},{name:"Subtle Highlight Answers",description:"Toggles subtle highlight answers on",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e=d(),a=e.state.question||e.props.client.question;let o=0;for(;o<a.answers.length;){let e=0,t=!1;for(;e<a.correctAnswers.length;){if(a.answers[o]==a.correctAnswers[e]){t=!0;break}e++}o++,t&&(document.querySelector("[class*='answersHolder'] :nth-child("+o+") > div").style.boxShadow="unset")}},50))}},{name:"Percent Auto Answer",description:"Answers questions correctly or incorrectly depending on the goal grade given (Disable and re-enable to update goal)",type:"toggle",enabled:!1,data:null,run:function(){if(this.enabled)this.enabled=!1,clearInterval(this.data),this.data=null;else{this.enabled=!0;var e=parseFloat(c("What grade do you want to get from this set? (0-100)"));const i=d();this.data=setInterval(a=>{try{var o=i.state.question||i.props.client.question;if("feedback"==i.state.stage||i.state.feedback)return document.querySelector('[class*="feedback"], [id*="feedback"]')?.firstChild?.click?.();if(document.querySelector("[class*='answerContainer']")||document.querySelector("[class*='typingAnswerWrapper']")){let e=0,t=0;for(var n in i.corrects)e+=i.corrects[n];for(var s in i.incorrects)t+=i.incorrects[s];var r=0==(t+=e)||Math.abs(e/(t+1)-a)>=Math.abs((e+1)/(t+1)-a);if("typing"!=i.state.question.qType){var l=document.querySelectorAll("[class*='answerContainer']");for(let e=0;e<l.length;e++)if(r==o.correctAnswers.includes(o.answers[e]))return l[e]?.click?.();l[0].click()}else Object.values(document.querySelector("[class*='typingAnswerWrapper']"))[1].children._owner.stateNode.sendAnswer(r?o.answers[0]:Math.random().toString(36).substring(2))}}catch{}},100,e/100)}}},{name:"Auto Answer",description:"Click the correct answer for you",run:function(){var e=d(),o=e.state.question||e.props.client.question;if("typing"!=e.state.question.qType)if("feedback"==e.state.stage||e.state.feedback)document.querySelector("[class*='feedback'], [id*='feedback']").firstChild.click();else{let a;for(a=0;a<o.answers.length;a++){let t=!1;for(let e=0;e<o.correctAnswers.length;e++)if(o.answers[a]==o.correctAnswers[e]){t=!0;break}if(t)break}document.querySelectorAll("[class*='answerContainer']")[a].click()}else Object.values(document.querySelector("[class*='typingAnswerWrapper']"))[1].children._owner.stateNode.sendAnswer(o.answers[0])}},{name:"Highlight Answers",description:"Colors answers to be red or green highlighting the correct ones",run:function(){var e=d(),a=e.state.question||e.props.client.question;let o=0;for(;o<a.answers.length;){let t=!1;for(let e=0;e<a.correctAnswers.length;e++)if(a.answers[o]==a.correctAnswers[e]){t=!0;break}o++,document.querySelector("[class*='answersHolder'] :nth-child("+o+") > div").style.backgroundColor=t?"rgb(0, 207, 119)":"rgb(189, 15, 38)"}}},{name:"Spam Buy Blooks",description:"Opens a box an amount of times",run:async function(){if(window.__blPath().startsWith("/market")){var t=d(),e=Array.prototype.reduce.call(document.querySelectorAll("[class*='packsWrapper'] > div"),(e,t)=>(t.querySelector("[class*='blookContainer'] > img")||(e[t.querySelector("[class*='packImgContainer'] > img").alt]=parseInt(t.querySelector("[class*='packBottom']").textContent)),e),{}),a=c('Which box do you want to open? (ex: "Ice Monster")').split(" ").map(e=>e.charAt(0).toUpperCase()+e.slice(1).toLowerCase()).join(" "),e=e[a];if(!e)return l("I couldn't find that box!");e=Math.floor(t.state.tokens/e);if(e<=0)return l("You do not have enough tokens!");var o=Math.min(e,parseInt(c("How many boxes do you want to open?"))||0),n=i("Would you like to show blooks as unlocking?"),s={},e=Date.now();for(let e=0;e<o;e++){await t.buyPack(!0,a),s[t.state.unlockedBlook]||=0,s[t.state.unlockedBlook]++,t.startOpening(),clearTimeout(t.openTimeout);var r=t.state.purchasedBlookRarity;if(t.setState({canOpen:!0,currentPack:"",opening:n,doneOpening:n,openPack:n}),clearTimeout(t.canOpenTimeout),"Chroma"==r)break}await new Promise(e=>setTimeout(e)),l(%60(\${Date.now()-e}ms) Results:\\n%60+Object.entries(s).map(([e,t])=>%60    \${e} %60+t).join(%60\\n%60))}else l("This can only be ran in the Market page.")}},{name:"Host Any Gamemode",description:"Change the selected gamemode on the host settings page",run:function(){var e,t;"/host/settings"==window.__blPath()?(e=["Racing","Classic","Factory","Cafe","Defense2","Defense","Royale","Gold","Candy","Brawl","Hack","Pirate","Fish","Dino","Toy","Rush"],t=c(%60Which gamemode do you want to switch to? (Case sensitive)\\n\${e.slice(0,e.length-1).join(", ")} or %60+e[e.length-1]),e.includes(t)?d().setState({settings:{type:t}}):l("Gamemode not found, make sure you spelled and capitalized it right.")):l("Run this script on the host settings page")}},{name:"Change Blook Ingame",description:"Changes your blook",run:function(){var e=d()["props"];e.liveGameController.setVal({path:%60c/\${e.client.name}/b%60,val:e.client.blook=c("Blook Name: (Case Sensitive)")})}},{name:"Get Daily Rewards",description:"Gets max daily tokens and xp",run:async function(){var e,t,a;window.__blHref().includes("play.blooket.com")?(e=["60101da869e8c70013913b59","625db660c6842334835cb4c6","60268f8861bd520016eae038","611e6c804abdf900668699e3","60ba5ff6077eb600221b7145","642467af9b704783215c1f1b","605bd360e35779001bf57c5e","6234cc7add097ff1c9cff3bd","600b1491d42a140004d5215a","5db75fa3f1fa190017b61c0c","5fac96fe2ca0da00042b018f","600b14d8d42a140004d52165","5f88953cdb209e00046522c7","600b153ad42a140004d52172","5fe260e72a505b00040e2a11","5fe3d085a529560004cd3076","5f5fc017aee59500041a1456","608b0a5863c4f2001eed43f4","5fad491512c8620004918ace","5fc91a9b4ea2e200046bd49a","5c5d06a7deebc70017245da7","5ff767051b68750004a6fd21","5fdcacc85d465a0004b021b9","5fb7eea20bd44300045ba495"][Math.floor(24*Math.random())],t=(e,t)=>Math.floor(Math.random()*(t-e+1))+e,a=(await fetch("https://play.blooket.com/api/playersessions/solo",{body:JSON.stringify({gameMode:"Factory",questionSetId:e}),method:"POST",credentials:"include"}).then(e=>e.json()).catch(()=>l("There was an error creating a solo game.")))["t"],await fetch("https://play.blooket.com/api/playersessions/landings",{body:JSON.stringify({t:a}),method:"POST",credentials:"include"}).catch(()=>l("There was an error when landing.")),await fetch("https://play.blooket.com/api/playersessions/questions?t="+a,{credentials:"include"}),await fetch("https://play.blooket.com/api/gamequestionsets?gameId="+e,{credentials:"include"}),await fetch("https://play.blooket.com/api/users/factorystats",{body:JSON.stringify({t:a,place:1,cash:t(1e7,1e8),playersDefeated:0,correctAnswers:t(500,2e3),upgrades:t(250,750),blookUsed:"Chick",nameUsed:"You",mode:"Time-Solo"}),method:"PUT",credentials:"include"}).catch(()=>l("There was an error when spoofing stats.")),await fetch("https://play.blooket.com/api/users/add-rewards",{body:JSON.stringify({t:a,addedTokens:500,addedXp:300}),method:"PUT",credentials:"include"}).then(e=>e.json()).then(({dailyReward:e})=>l(%60Added max tokens and xp, and got \${e} daily wheel tokens!%60)).catch(()=>l("There was an error when adding rewards."))):(l("This cheat only works on play.blooket.com, opening a new tab."),window.open("https://play.blooket.com/"))}},{name:"Use Any Blook",description:"Allows you to play as any blook",data:null,getBlooks(t,e){if(!this.data?.Black){t=t?"keys":"entries";const a=Object[t],o=this;Object[t]=function(e){return(e.Chick?(o.data=e,Object[t]=a):a).call(this,e)},e.render()}},run:function(){const a=d();var e=window.__blPath().startsWith("/play/lobby");return!e&&window.__blPath().startsWith("/blooks")||e?(this.getBlooks(e,a),e?a.setState({unlocks:Object.keys(this.data)}):void a.setState({blookData:Object.keys(this.data).reduce((e,t)=>(e[t]=a.state.blookData[t]||1,e),{}),allSets:Object.values(this.data).reduce((e,t)=>t.set&&e.includes(t.set)?e:e.concat(t.set),[])})):l("This only works in lobbies or the dashboard blooks page.")}},{name:"Every Answer Correct",description:"Sets every answer to be correct",run:function(){var t=d();for(let e=0;e<t.freeQuestions.length;e++)t.freeQuestions[e].correctAnswers=t.freeQuestions[e].answers,t.questions[e].correctAnswers=t.questions[e].answers,t.props.client.questions[e].correctAnswers=t.questions[e].answers;try{t.forceUpdate()}catch{}}},{name:"Subtle Highlight Answers",description:"Removes the shadow from correct answers",run:function(){var e=d(),a=e.state.question||e.props.client.question;let o=0;for(;o<a.answers.length;){let e=0,t=!1;for(;e<a.correctAnswers.length;){if(a.answers[o]==a.correctAnswers[e]){t=!0;break}e++}o++,t&&(document.querySelector("[class*='answersHolder'] :nth-child("+o+") > div").style.boxShadow="unset")}}},{name:"Remove Random Name",description:"Allows you to put a custom name",run:function(){d().setState({isRandom:!1,client:{name:""}}),document.querySelector('[class*="nameInput"]')?.focus?.()}},{name:"Sell Duplicate Blooks",description:"Sell all duplicate blooks leaving you with 1 each",run:async function(){if(window.__blPath().startsWith("/blooks")){if(i("Are you sure you want to sell your dupes? (Legendaries and rarer will not be sold)")){var a=d();let e=Date.now(),t="";for(const o in a.state.blookData)if(1<a.state.blookData[o]){if(a.setState({blook:o,numToSell:a.state.blookData[o]-1}),!["Uncommon","Rare","Epic"].includes(document.querySelector("[class*='highlightedRarity']").innerText.trim()))continue;t+=%60    \${o} \${a.state.blookData[o]-1}\\n%60,await a.sellBlook({preventDefault:()=>{}},!0)}l(%60(\${Date.now()-e}ms) Results:\\n%60+t.trim())}}else l("This can only be ran in the Blooks page.")}}],gold:[{name:"Always Triple",description:"Always get triple gold",type:"toggle",enabled:!1,data:{type:"multiply",val:3,text:"Triple Gold!",blook:"Unicorn"},run:function(){let t=d();t._choosePrize||=t.choosePrize,this.enabled?(this.enabled=!1,t._choosePrize&&(t.choosePrize=t._choosePrize)):(this.enabled=!0,t.choosePrize=e=>{t.state.choices[e]=this.data,t._choosePrize(e)})}},{name:"Auto Choose",description:"Automatically picks the option that would give you the most gold",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(async()=>{let r=d();"prize"==r.state.stage&&r.props.liveGameController.getDatabaseVal("c",t=>{try{if(null!=t){t=Object.entries(t);let a=0,o=0,n=-1;for(let e=0;e<t.length;e++)t[e][0]!=r.props.client.name&&t[e][1]>a&&(a=t[e][1]);for(let t=0;t<r.state.choices.length;t++){var s=r.state.choices[t];let e=r.state.gold;"gold"==s.type?e=r.state.gold+s.val||r.state.gold:"multiply"==s.type||"divide"==s.type?e=Math.round(r.state.gold*s.val)||r.state.gold:"swap"==s.type?e=a||r.state.gold:"take"==s.type&&(e=r.state.gold+a*s.val||r.state.gold),(e||0)<=o||(o=e,n=t+1)}document.querySelector("div[class*='choice"+n+"']")?.click()}}catch{}})},50))}},{name:"Chest ESP",description:"Shows what each chest will give you",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{d().state.choices.forEach(({text:e},t)=>{var a,t=document.querySelector(%60div[class*='choice\${t+1}']%60);t&&!t.querySelector("div")&&((a=document.createElement("div")).style.color="white",a.style.fontFamily="Eczar",a.style.fontSize="2em",a.style.display="flex",a.style.justifyContent="center",a.style.transform="translateY(200px)",a.innerText=e,t.append(a))})},50))}},{name:"Remove Bad Choices",description:"Removes the chance of getting Lose 25%, Lose 50%, and Nothing",run:function(){let e=Array.prototype[Symbol.iterator];Array.prototype[Symbol.iterator]=function*(){if("gold"==this[0]?.type){Array.prototype[Symbol.iterator]=e,console.log(this);for(let e=0;e<this.length;e++)"divide"!=this[e].type&&"nothing"!=this[e].type||this.splice(e--,1)}yield*e.apply(this)},d().constructor.prototype.answerNext.call({nextReady:!0,here:!0,state:{correct:!0},setState(){}})}},{name:"Reset Players Gold",description:"Sets a player's gold to 0",run:function(){var e=d();e.props.liveGameController.setVal({path:"c/"+e.props.client.name+"/tat",val:c("Who's gold would you like to reset? (Case sensitive)")+":swap:0"})}},{name:"Set Gold",description:"Sets amount of gold",run:function(){var e=parseInt(c("How much gold would you like?"))||0,t=d();t.setState({gold:e,gold2:e}),t.props.liveGameController.setVal({path:"c/"+t.props.client.name+"/g",val:e})}},{name:"Set Player's Gold",description:"Sets another player's gold",run:function(){var e=document.createElement("iframe"),e=(document.body.append(e),window.prompt=e.contentWindow.prompt.bind(window),e.remove(),c("Who's gold would you like to set?")),t=parseInt(c("How much gold would you like to set?"))||0,a=d();a.props.liveGameController.setVal({path:"c/"+a.props.client.name+"/tat",val:e+":swap:"+t})}},{name:"Swap Gold",description:"Swaps gold with someone",run:function(){const t=c("Who's gold would you like to swap with? (Case sensitive)");let a=d();a.props.liveGameController.getDatabaseVal("c",e=>{e&&null!=e[t]&&(e=e[t].g||0,a.props.liveGameController.setVal({path:"c/"+a.props.client.name,val:{b:a.props.client.blook,tat:t+":swap:"+(a.state.gold||0),g:e}}),a.setState({gold:e,gold2:e}))})}}],hack:[{name:"Choice ESP",description:"Shows what each choice will give you",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e,t=document.querySelector("[class*=feedbackContainer]");t.children.length<=4&&((e=document.createElement("div")).style.color="white",e.style.fontFamily="Inconsolata,Helvetica,monospace,sans-serif",e.style.fontSize="2em",e.style.display="flex",e.style.justifyContent="center",e.style.marginTop="675px",e.innerText=d().state.choices[0].text,t.append(e))},50))}},{name:"Password ESP",description:"Highlights the correct password",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e=d()["state"];if("hack"==e.stage)for(const t of document.querySelector("div[class*=buttonContainer]").children)t.innerText!=e.correctPassword&&(t.style.outlineColor="rgba(255, 64, 64, 0.8)",t.style.backgroundColor="rgba(255, 64, 64, 0.8)",t.style.textShadow="0 0 1px #f33")},50))}},{name:"Always Triple",description:"Always get triple crypto",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(e=>d().setState(e),25,{choices:[{type:"mult",val:3,rate:.075,blook:"Brainy Bot",text:"Triple Crypto"}]}))}},{name:"Auto Guess",description:"Automatically guess the correct password",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e=d()["state"];if("hack"==e.stage)for(const t of document.querySelector("div[class*=buttonContainer]").children)t.innerText==e.correctPassword&&t.click()},50))}},{name:"Remove Hack",description:"Removes an attacking hack",run:function(){d().setState({hack:""})}},{name:"Set Crypto",description:"Sets crypto",run:function(){var e=parseInt(c("How much crypto would you like?"))||0,t=d();t.setState({crypto:e,crypto2:e}),t.props.liveGameController.setVal({path:%60c/\${t.props.client.name}/cr%60,val:e})}},{name:"Set Password",description:"Sets hacking password",run:function(){var e=c("What do you want to set your password to?"),t=d();t.setState({password:e}),t.props.liveGameController.setVal({path:%60c/\${t.props.client.name}/p%60,val:e})}},{name:"Steal Player's Crypto",description:"Steals all of someone's crypto",run:function(){let a=c("Who's crypto would you like to steal?"),o=d();o.props.liveGameController.getDatabaseVal("c",e=>{let t;e&&(t=Object.entries(e).find(e=>e[0].toLowerCase()==a.toLowerCase()))&&(e=t[1].cr,o.setState({crypto:o.state.crypto+e,crypto2:o.state.crypto+e}),o.props.liveGameController.setVal({path:"c/"+o.props.client.name,val:{b:o.props.client.blook,p:o.state.password,cr:o.state.crypto+e,tat:t[0]+":"+e}}))})}}],fish:[{name:"Remove Distractions",description:"Removes distractions",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{d().setState({party:""})},50))}},{name:"Frenzy",description:"Sets everyone to frenzy mode",run:function(){var e=d();e.props.liveGameController.setVal({path:"c/"+e.props.client.name,val:{b:e.props.client.blook,w:e.state.weight,f:"Frenzy",s:!0}})}},{name:"Send Distraction",description:"Sends a distraction to everyone",data:["Crab","Jellyfish","Frog","Pufferfish","Octopus","Narwhal","Megalodon","Blobfish","Baby Shark"],run:function(){var e=d(),t=this.data[Math.floor(Math.random()*this.data.length)];e.safe=!0,e.props.liveGameController.setVal({path:"c/"+e.props.client.name,val:{b:e.props.client.blook,w:e.state.weight,f:t,s:!0}}),l(%60Sent a \${t} distraction%60)}},{name:"Set Lure",description:"Sets fishing lure (range 1 - 5)",run:function(){d().setState({lure:Math.max(Math.min((parseInt(c("What would you like to set your lure to? (1 - 5)"))||1)-1,4),0)})}},{name:"Set Weight",description:"Sets weight",run:function(){var e=parseInt(c("How much weight would you like?"))||0,t=d();t.setState({weight:e,weight2:e}),t.props.liveGameController.setVal({path:"c/"+t.props.client.name,val:{b:t.props.client.blook,w:e,f:["Crab","Jellyfish","Frog","Pufferfish","Octopus","Narwhal","Megalodon","Blobfish","Baby Shark"][Math.floor(9*Math.random())]}})}}],pirate:[{name:"Heist ESP",description:"Shows you what's under each chest during a heist",type:"toggle",enabled:!1,data:null,imgs:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e=d();if("heist"==e.state.stage){null==this.imgs&&(this.imgs=Array.prototype.map.call(Array.prototype.slice.call(document.querySelector("[class*=prizesList]").children,1,4),e=>e.querySelector("img").src));const n=Object.values(document.querySelector("[class*=modal]"))[0].return.memoizedState.memoizedState;for(const t of document.querySelectorAll("[class*=boxContent] > div"))t.remove();const s=Object.values(document.querySelector("[class*=modal]"))[0].return.memoizedState.next.next.memoizedState;Array.prototype.forEach.call(document.querySelector("[class*=chestsWrapper]").children,(e,t)=>{const a=e.firstChild.firstChild;if(s.includes(t))return a.style.opacity="";a.style.opacity="0.5";let o=document.createElement("div");o.innerHTML="<img src='"+this.imgs[2-n[t]]+"' style='max-width: 75%; max-height: 75%'></img>",o.className="chestESP",o.style.position="absolute",o.style.inset="0",o.style.display="grid",o.style.placeItems="center",o.style.pointerEvents="none",e.onclick=()=>{o.remove(),a.style.opacity=""},e.firstChild.prepend(o)})}},50))}},{name:"Max Levels",description:"Maxes out all islands and your boat",run:function(){var e=d();e.setState({islandLevels:new Array(e.state.islandLevels.length).fill(5)},e.updateBoatLevel)}},{name:"Set Doubloons",description:"Sets Doubloons",run:function(){var e=parseInt(c("How many doubloons do you want?"))||0,t=d();t.setState({doubloons:e}),t.props.liveGameController.setVal({path:%60c/\${t.props.client.name}/d%60,val:e})}},{name:"Start Heist",description:"Starts a heist on someone",run:function(){let n=d();n.props.liveGameController.getDatabaseVal("c",function(e){if(null!=e){var a=[];for(const o in e)o!=n.props.client.name&&a.push({name:o,blook:e[o].b,doubloons:e[o].d||0});if(0==a.length)n.questionsToAnswer=1,n.randomQ();else{const o=c("Who would you like to heist? (Case sensitive, defaults to top player if no one found)");let t=a.find(e=>e.name==o);if(null==t){t=a[0];for(let e=1;e<a.length;e++)a[e].doubloons>t.doubloons&&(t=a[e])}n.setState({stage:"heist",heistInfo:{name:t.name,blook:t.blook},prizeAmount:Math.max(1e3,t.doubloons)})}}})}},{name:"Swap Doubloons",description:"Swaps Doubloons with someone",run:async function(){let n=d();n.props.liveGameController.getDatabaseVal("c",function(e){if(null!=e){var a=[];for(const o in e)o!=n.props.client.name&&a.push({name:o,blook:e[o].b,doubloons:e[o].d||0});if(0==a.length)return l("You're the only one here.");const o=c("Who would you like to swap with? (Case sensitive, defaults to top player if no one found)");let t=a.find(e=>e.name==o);if(null==t){t=a[0];for(let e=1;e<a.length;e++)a[e].doubloons>t.doubloons&&(t=a[e])}n.props.liveGameController.setVal({path:"c/"+n.props.client.name,val:{b:n.props.client.blook,d:t.doubloons,tat:t.name+":"+(t.doubloons-n.state.doubloons)}}),n.setState({doubloons:t.doubloons})}})}},{name:"Take Doubloons",description:"Takes Doubloons from someone",run:async function(){let n=d();n.props.liveGameController.getDatabaseVal("c",function(e){if(null!=e){var a=[];for(const o in e)o!=n.props.client.name&&a.push({name:o,blook:e[o].b,doubloons:e[o].d||0});if(0==a.length)return l("You're the only one here.");const o=c("Who would you like to take from? (Case sensitive, defaults to top player if no one found)");let t=a.find(e=>e.name==o);if(null==t){t=a[0];for(let e=1;e<a.length;e++)a[e].doubloons>t.doubloons&&(t=a[e])}n.props.liveGameController.setVal({path:"c/"+n.props.client.name,val:{b:n.props.client.blook,d:n.state.doubloons+t.doubloons,tat:t.name+":"+t.doubloons}}),n.setState({doubloons:n.state.doubloons+t.doubloons})}})}}],defense2:[{name:"Max Tower Stats",description:"Makes all placed towers overpowered",run:function(){d().state.towers.forEach(e=>{if(e.stats.dmg=1e6,e.stats.fireRate=50,e.stats.ghostDetect=!0,e.stats.maxTargets=1e6,e.stats.numProjectiles&&=100,e.stats.range=100,e.stats.auraBuffs)for(const t in e.stats.auraBuffs)e.stats.auraBuffs[t]*=100})}},{name:"Kill Enemies",description:"Kills all the enemies",run:function(){var e=d();e.game.current.config.sceneConfig.enemyQueue.length=0,e.game.current.config.sceneConfig.physics.world.bodies.entries.forEach(e=>e?.gameObject?.receiveDamage?.(e.gameObject.hp,1))}},{name:"Set Coins",description:"Sets coins",run:function(){d().setState({coins:parseInt(c("How many coins would you like?"))||0})}},{name:"Set Health",description:"Sets the amount of health you have",run:function(){d().setState({health:parseInt(c("How much health would you like?"))||0})}},{name:"Set Round",description:"Sets the current round",run:function(){d().setState({round:parseInt(c("What round do you want to set to?"))||0})}}],brawl:[{name:"Double Enemy XP",description:"Doubles enemy XP drop value",run:function(){var a=d().game.current.config.sceneConfig.physics.world.colliders._active.filter(e=>e.callbackContext?.toString?.()?.includes?.("dmgCd"));for(let t=0;t<a.length;t++){var o=a[t].object2;let e=o.classType.prototype.start;o.classType.prototype.start=function(){e.apply(this,arguments),this.val*=2},o.children.entries.forEach(e=>e.val*=2)}}},{name:"Half Enemy Speed",description:"Makes enemies move 2x slower",run:function(){var a=d().game.current.config.sceneConfig.physics.world.colliders._active.filter(e=>e.callbackContext?.toString?.()?.includes?.("dmgCd"));for(let t=0;t<a.length;t++){var o=a[t].object2;let e=o.classType.prototype.start;o.classType.prototype.start=function(){e.apply(this,arguments),this.speed*=.5},o.children.entries.forEach(e=>e.speed*=.5)}}},{name:"Instant Kill",description:"Sets all enemies health to 1",run:function(){var a=d().game.current.config.sceneConfig.physics.world.colliders._active.filter(e=>e.callbackContext?.toString?.()?.includes?.("dmgCd"));for(let t=0;t<a.length;t++){var o=a[t].object2;let e=o.classType.prototype.start;o.classType.prototype.start=function(){e.apply(this,arguments),this.hp=1},o.children.entries.forEach(e=>e.hp=1)}}},{name:"Invincibility",description:"Makes you invincible",run:function(){for(const e of d().game.current.config.sceneConfig.physics.world.colliders._active.filter(e=>e.callbackContext?.toString().includes("invulnerableTime")||e.callbackContext?.toString().includes("dmgCd")))e.collideCallback=()=>{}}},{name:"Kill Enemies",description:"Kills all current enemies",run:function(){d().game.current.config.sceneConfig.physics.world.bodies.entries.forEach(e=>e?.gameObject?.receiveDamage?.(e.gameObject.hp,1))}},{name:"Magnet",description:"Pulls all xp towards you",run:function(){d().game.current.config.sceneConfig.physics.world.colliders._active.find(e=>e.collideCallback?.toString().includes("magnetTime")).collideCallback({active:!0},{active:!0,setActive(){},setVisible(){}})}},{name:"Max Current Abilities",description:"Maxes out all your current abilities",run:function(){const a=d();for(var[t,o]of Object.entries(a.state.abilities))for(let e=0;e<10-o;e++)a.game.current.config.sceneConfig.game.events.emit("level up",t,a.state.abilities[t]++);a.setState({level:a.game.current.config.sceneConfig.level=[1,3,5,10,15,25,35].sort((e,t)=>Math.abs(e-a.state.level)-Math.abs(t-a.state.level))[0]-1})}},{name:"Next Level",description:"Skips to the next level",run:function(){var e=d(),{object1:t,object2:a}=e.game.current.config.sceneConfig.physics.world.colliders._active.find(e=>e.collideCallback?.toString().includes('emit("xp'));a.get().spawn(t.x,t.y,(1===(a=e.state.level)?1:a<5?5:a<10?10:a<20?20:a<30?30:a<40?40:a<50?50:100)-e.xp)}},{name:"Remove Obstacles",description:"Removes all rocks and obstacles",run:function(){d().game.current.config.sceneConfig.physics.world.bodies.entries.forEach(e=>{try{e.gameObject.frame.texture.key.includes("obstacle")&&e.gameObject.destroy()}catch{}})}},{name:"Reset Health",description:"Resets health and gives invincibility for 3 seconds",run:function(){d().game.current.events._events.respawn.fn()}}],dino:[{name:"Auto Choose",description:"Automatically choose the best fossil when excavating",type:"toggle",enabled:!1,data:null,rand(o,e){for(var n=[];n.length<e;){var s=Math.random();let t=0,a=null;for(let e=0;e<o.length;e++)if((t+=o[e].rate)>=s){a=o[e];break}a&&!n.includes(a)&&n.push(a)}return n},run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{try{var o=d();if("excavate"===o.state.stage){o.state.choices.length||(o.state.choices=this.rand([{type:"fossil",val:10,rate:.1,blook:"Amber"},{type:"fossil",val:25,rate:.1,blook:"Dino Egg"},{type:"fossil",val:50,rate:.175,blook:"Dino Fossil"},{type:"fossil",val:75,rate:.175,blook:"Stegosaurus"},{type:"fossil",val:100,rate:.15,blook:"Velociraptor"},{type:"fossil",val:125,rate:.125,blook:"Brontosaurus"},{type:"fossil",val:250,rate:.075,blook:"Triceratops"},{type:"fossil",val:500,rate:.025,blook:"Tyrannosaurus Rex"},{type:"mult",val:1.5,rate:.05},{type:"mult",val:2,rate:.025}],3));let t=0,a=-1;for(let e=0;e<o.state.choices.length;e++){var{type:n,val:s}=o.state.choices[e],r=("fossil"==n?o.state.fossils+s*o.state.fossilMult:o.state.fossils*s)||0;r<=t&&"mult"!=n||(t=r,a=e+1)}document.querySelector('div[class*=rockRow] > div[role="button"]:nth-child('+a+")").click()}}catch{}},50))}},{name:"Rock ESP",description:"Shows what is under the rocks",type:"toggle",enabled:!1,data:null,run:(()=>{const a=["\u2070","\xB9","\xB2","\xB3","\u2074","\u2075","\u2076","\u2077","\u2078","\u2079"],s=e=>{let t="";for(;0<e;)t=a[e% 10]+t,e=~~(e/10);return t};return function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{let o=d();const e=document.querySelector('[class*="rockButton"]').parentElement.children;Array.prototype.every.call(e,e=>e.querySelector("div"))||o.setState({choices:function(o,e){for(var n=[];n.length<e;){var s=Math.random();let t=0,a;for(let e=0;e<o.length;e++)if((t+=o[e].rate)>=s){a=o[e];break}a&&!n.includes(a)&&n.push(a)}return n}([{type:"fossil",val:10,rate:.1,blook:"Amber"},{type:"fossil",val:25,rate:.1,blook:"Dino Egg"},{type:"fossil",val:50,rate:.175,blook:"Dino Fossil"},{type:"fossil",val:75,rate:.175,blook:"Stegosaurus"},{type:"fossil",val:100,rate:.15,blook:"Velociraptor"},{type:"fossil",val:125,rate:.125,blook:"Brontosaurus"},{type:"fossil",val:250,rate:.075,blook:"Triceratops"},{type:"fossil",val:500,rate:.025,blook:"Tyrannosaurus Rex"},{type:"mult",val:1.5,rate:.05},{type:"mult",val:2,rate:.025}],3)},()=>{Array.prototype.forEach.call(e,(e,t)=>{var t=o.state.choices[t],a=(e.querySelector("div")&&e.querySelector("div").remove(),document.createElement("div"));a.style.color="white",a.style.fontFamily="Macondo",a.style.fontSize="1em",a.style.display="flex",a.style.justifyContent="center",a.style.transform="translateY(25px)",a.innerText="fossil"===t.type?%60+\${99999999<Math.round(t.val*o.state.fossilMult)?function(a){let o=a.toString();if(1e3<=a){var e=["","K","M","B","T"],n=Math.floor(Math.floor((Math.log(a)/Math.log(10)).toPrecision(14))/3);if(n<e.length){let t="";for(let e=3;1<=e;e--)if((t=parseFloat((0!=n?a/Math.pow(1e3,n):a).toPrecision(e)).toString()).replace(/[^a-zA-Z 0-9]+/g,"").length<=3)break;Number(t)% 1!=0&&(t=Number(t).toFixed(1)),o=t+e[n]}else{let e=a,t=0;for(;100<=e;)e=Math.floor(e/10),t+=1;o=e/10+" \xD7 10"+s(t+1)}}return o}(Math.round(t.val*o.state.fossilMult)):Math.round(t.val*o.state.fossilMult)} Fossils%60:%60x\${t.val} Fossils Per Excavation%60,e.append(a)})})},50))}})()},{name:"Set Fossils",description:"Sets the amount of fossils you have",run:function(){var e=parseInt(c("How many fossils would you like?"))||0,t=d();t.setState({fossils:e}),t.props.liveGameController.setVal({path:%60c/\${t.props.client.name}/f%60,val:e})}},{name:"Set Multiplier",description:"Sets fossil multiplier",run:function(){d().stateNode.setState({fossilMult:parseInt(c("What do you want your multiplier to be?"))||0})}},{name:"Stop Cheating",description:"Undoes cheating so that you can't be caught",run:function(){var e=d();e.setState({isCheating:!1}),e.props.liveGameController.setVal({path:%60c/\${e.props.client.name}/ic%60,val:!1})}}],royale:[{name:"Auto Answer (Toggle)",description:"Toggles auto answer on",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),this.data=null):(this.enabled=!0,this.data=setInterval(()=>{var e=d();e?.onAnswer?.(!0,e.props.client.question.correctAnswers[0])},50))}},{name:"Auto Answer",description:"Chooses the correct answer for you",run:function(){var e=d();e?.onAnswer?.(!0,e.props.client.question.correctAnswers[0])}}],defense:[{name:"Earthquake",description:"Shuffles around towers",run:function(){let o=d(),n=(o.setState({eventName:"Earthquake",event:{short:"e",color:"#805500",icon:"fas fa-mountain",desc:"All of your towers get mixed up",rate:.02},buyTowerName:"",buyTower:{}},()=>o.eventTimeout=setTimeout(()=>o.setState({event:{},eventName:""}),6e3)),o.tiles.forEach(a=>a.forEach((e,t)=>3==e&&(a[t]=0))),[]);for(let t=0;t<o.tiles.length;t++)for(let e=0;e<o.tiles[t].length;e++)0==o.tiles[t][e]&&n.push({x:e,y:t});n.sort(()=>Math.random()-Math.random()),o.towers.forEach(e=>{var{x:t,y:a}=n.pop();e.move(t,a,o.tileSize),o.tiles[a][t]=3})}},{name:"Max Tower Stats",description:"Makes all placed towers overpowered",run:function(){d().towers.forEach(e=>{e.range=100,e.fullCd=e.cd=0,e.damage=1e6})}},{name:"Remove Ducks",description:"Removes ducks",run:function(){let{ducks:e,tiles:t}=d();e.forEach(e=>t[e.y][e.x]=0),e.length=0}},{name:"Remove Enemies",description:"Removes all the enemies",run:function(){var e=d();e.enemies=e.futureEnemies=[]}},{name:"Remove Obstacles",description:"Lets you place towers anywhere",run:function(){var e=d();e.tiles=e.tiles.map(e=>e.fill(0))}},{name:"Set Damage",description:"Sets damage",run:function(){d().dmg=parseInt(c("How much dmg would you like?"))||0}},{name:"Set Round",description:"Sets the current round",run:function(){d().setState({round:parseInt(c("What round do you want to set to?"))||0})}},{name:"Set Tokens",description:"Sets the amount of tokens you have",run:function(){d().setState({tokens:parseInt(c("How many tokens would you like?"))||0})}}],cafe:[{name:"Max Items",description:"Maxes out items in the shop (Only usable in the shop)",run:function(){var e;"/cafe/shop"!==window.__blPath()?l("This can only be run in the shop"):(e=d()).setState({items:Object.keys(e.state.items).reduce((e,t)=>(e[t]=5,e),{})})}},{name:"Remove Customers",description:"Skips the current customers (Not usable in the shop)",run:function(){const a=d();a.state.customers.forEach((e,t)=>window.setTimeout(()=>e.blook&&a.removeCustomer(t,!0),250*t))}},{name:"Reset Abilities",description:"Resets used abilities in shop (Only usable in the shop)",run:function(){var e;"/cafe/shop"!==window.__blPath()?l("This can only be run in the shop"):(e=d()).setState({abilities:Object.keys(e.state.abilities).reduce((e,t)=>(e[t]=5,e),{})})}},{name:"Set Cash",description:"Sets cafe cash",run:function(){var e=parseInt(c("How much cash would you like?"))||0,t=d();t.setState({cafeCash:e}),t.props.liveGameController.setVal({path:%60c/\${t.props.client.name}/ca%60,val:e})}},{name:"Stock Food",description:"Stocks all food to 99 (Not usable in the shop)",run:function(){var e;"/cafe"!==window.__blPath()?l("This can't be run in the shop"):(e=d()).setState({foods:e.state.foods.map(e=>({...e,stock:99,level:5}))})}}],factory:[{name:"Choose Blook",description:"Gives you a blook",data:[{name:"Chick",color:"#ffcd05",class:"\u{1F33D}",rarity:"Common",cash:[3,7,65,400,2500],time:[1,1,1,1,1],price:[300,3e3,3e4,2e5]},{name:"Chicken",color:"#ed1c24",class:"\u{1F33D}",rarity:"Common",cash:[10,40,200,1400,1e4],time:[5,4,3,2,1],price:[570,4e3,5e4,8e5]},{name:"Cow",color:"#58595b",class:"\u{1F33D}",rarity:"Common",cash:[25,75,1500,25e3,25e4],time:[15,10,10,10,5],price:[500,9500,16e4,4e6]},{name:"Duck",color:"#4ab96d",class:"\u{1F33D}",rarity:"Common",cash:[4,24,200,3e3,4e4],time:[3,3,3,3,3],price:[450,4200,7e4,11e5]},{name:"Goat",color:"#c59a74",class:"\u{1F33D}",rarity:"Common",cash:[5,28,200,1300,12e3],time:[3,3,2,2,2],price:[500,6400,45e3,5e5]},{name:"Horse",color:"#995b3c",class:"\u{1F33D}",rarity:"Common",cash:[5,20,270,1800,15e3],time:[2,2,2,2,2],price:[550,8200,65e3,6e5]},{name:"Pig",color:"#f6a9cb",class:"\u{1F33D}",rarity:"Common",cash:[20,50,1300,8e3,8e4],time:[7,7,7,7,5],price:[400,11e3,8e4,13e5]},{name:"Sheep",color:"#414042",class:"\u{1F33D}",rarity:"Common",cash:[6,25,250,1500,11e3],time:[3,3,3,2,2],price:[500,5e3,5e4,43e4]},{name:"Cat",color:"#f49849",class:"\u{1F43E}",rarity:"Common",cash:[5,18,170,1700,13e3],time:[2,2,2,2,2],price:[480,5500,6e4,5e5]},{name:"Dog",color:"#995b3c",class:"\u{1F43E}",rarity:"Common",cash:[7,25,220,1900,9e3],time:[3,3,2,2,1],price:[460,6600,7e4,73e4]},{name:"Goldfish",color:"#f18221",class:"\u{1F43E}",rarity:"Common",cash:[5,40,350,3500,35e3],time:[3,3,3,3,3],price:[750,7200,84e3,95e4]},{name:"Rabbit",color:"#e7bf9a",class:"\u{1F43E}",rarity:"Common",cash:[3,18,185,800,7e3],time:[2,2,2,1,1],price:[500,5800,56e3,55e4]},{name:"Hamster",color:"#ce9176",class:"\u{1F43E}",rarity:"Common",cash:[10,45,450,4500,45e3],time:[4,4,4,4,4],price:[650,6500,8e4,93e4]},{name:"Turtle",color:"#619a3c",class:"\u{1F43E}",rarity:"Common",cash:[23,120,1400,15e3,17e4],time:[10,10,10,10,10],price:[700,8500,11e4,13e5]},{name:"Puppy",color:"#414042",class:"\u{1F43E}",rarity:"Common",cash:[4,10,75,500,3e3],time:[1,1,1,1,1],price:[450,4e3,35e3,25e4]},{name:"Kitten",color:"#58595b",class:"\u{1F43E}",rarity:"Common",cash:[4,8,60,400,2e3],time:[1,1,1,1,1],price:[350,3500,26e3,17e4]},{name:"Bear",color:"#995b3c",class:"\u{1F332}",rarity:"Common",cash:[12,70,550,4500,1e5],time:[7,7,6,5,5],price:[550,5500,63e3,16e5]},{name:"Moose",color:"#995b3c",class:"\u{1F332}",rarity:"Common",cash:[8,45,400,3500,26e3],time:[5,5,4,4,3],price:[520,6500,58e3,7e5]},{name:"Fox",color:"#f49849",class:"\u{1F332}",rarity:"Common",cash:[7,15,80,550,3e3],time:[2,2,1,1,1],price:[400,4e3,36e3,24e4]},{name:"Raccoon",color:"#6d6e71",class:"\u{1F332}",rarity:"Common",cash:[5,14,185,1900,19e3],time:[2,2,2,2,2],price:[400,5e3,71e3,8e5]},{name:"Squirrel",color:"#d25927",class:"\u{1F332}",rarity:"Common",cash:[3,10,65,470,2600],time:[1,1,1,1,1],price:[420,3600,32e3,21e4]},{name:"Owl",color:"#594a42",class:"\u{1F332}",rarity:"Common",cash:[4,17,155,1500,15e3],time:[2,2,2,2,2],price:[500,4800,55e3,58e4]},{name:"Hedgehog",color:"#3f312b",class:"\u{1F332}",rarity:"Common",cash:[11,37,340,2200,3e4],time:[5,4,3,2,2],price:[540,7e3,77e3,12e5]},{name:"Seal",color:"#7ca1d5",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[6,17,150,1200,13e3],time:[2,2,2,2,2],price:[480,4500,43e3,52e4]},{name:"Arctic Fox",color:"#7ca1d5",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[5,18,180,850,8500],time:[2,2,2,1,1],price:[520,550,61e3,68e4]},{name:"Snowy Owl",color:"#feda3f",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[5,20,190,1900,16e3],time:[3,3,2,2,2],price:[370,5300,76e3,62e4]},{name:"Arctic Hare",color:"#7ca1d5",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[6,19,85,900,7e3],time:[2,2,1,1,1],price:[540,5200,66e3,55e4]},{name:"Penguin",color:"#fb8640",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[4,21,310,3200,33e3],time:[3,3,3,3,3],price:[400,6500,76e3,87e4]},{name:"Baby Penguin",color:"#414042",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[3,8,70,450,2700],time:[1,1,1,1,1],price:[420,3300,33e3,23e4]},{name:"Polar Bear",color:"#7ca1d5",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[12,75,700,6500,85e3],time:[8,7,6,5,5],price:[630,7e3,91e3,14e5]},{name:"Walrus",color:"#7d4f33",class:"\u2744%EF%B8%8F",rarity:"Common",cash:[11,46,420,3700,51e3],time:[5,5,4,4,4],price:[550,6200,68e3,1e6]},{name:"Tiger",color:"#f18221",class:"\u{1F334}",rarity:"Common",cash:[6,20,100,975,7500],time:[3,3,1,1,1],price:[390,6e3,7e4,61e4]},{name:"Jaguar",color:"#fbb040",class:"\u{1F334}",rarity:"Common",cash:[8,28,230,1600,17e3],time:[3,3,2,2,2],price:[390,6e3,7e4,61e4]},{name:"Toucan",color:"#ffca34",class:"\u{1F334}",rarity:"Common",cash:[9,20,175,625,3800],time:[2,2,2,1,1],price:[520,4800,42e3,3e5]},{name:"Cockatoo",color:"#7ca1d5",class:"\u{1F334}",rarity:"Common",cash:[6,35,160,1700,18e3],time:[4,4,2,2,2],price:[500,5e3,63e3,7e5]},{name:"Macaw",color:"#00aeef",class:"\u{1F334}",rarity:"Common",cash:[3,8,85,850,8500],time:[1,1,1,1,1],price:[480,5400,62e3,63e4]},{name:"Parrot",color:"#ed1c24",class:"\u{1F334}",rarity:"Common",cash:[3,9,90,900,9e3],time:[1,1,1,1,1],price:[540,5700,65e3,69e4]},{name:"Panther",color:"#2f2c38",class:"\u{1F334}",rarity:"Common",cash:[12,28,215,2100,21e3],time:[5,3,2,2,2],price:[530,6500,76e3,87e4]},{name:"Anaconda",color:"#8a9143",class:"\u{1F334}",rarity:"Common",cash:[3,15,85,1500,7600],time:[1,2,1,2,1],price:[410,5100,58e3,59e4]},{name:"Orangutan",color:"#bc6234",class:"\u{1F334}",rarity:"Common",cash:[13,52,570,4300,7e4],time:[5,5,5,4,4],price:[600,7e3,8e4,14e5]},{name:"Capuchin",color:"#e0b0a6",class:"\u{1F334}",rarity:"Common",cash:[4,14,160,780,8200],time:[2,2,2,1,1],price:[390,4700,57e3,68e4]},{name:"Elf",color:"#a7d054",class:"\u2694%EF%B8%8F",rarity:"Uncommon",cash:[5e3,15e3,15e4,15e5,1e7],time:[1,1,1,1,1],price:[8e5,9e6,11e7,8e8]},{name:"Witch",color:"#4ab96d",class:"\u2694%EF%B8%8F",rarity:"Uncommon",cash:[18e3,6e4,4e4,4e6,35e6],time:[3,3,2,2,2],price:[11e5,12e6,15e7,14e8]},{name:"Wizard",color:"#5a459c",class:"\u2694%EF%B8%8F",rarity:"Uncommon",cash:[19500,65e3,44e4,46e5,4e6],time:[3,3,2,2,2],price:[13e5,135e5,16e7,16e8]},{name:"Fairy",color:"#df6d9c",class:"\u2694%EF%B8%8F",rarity:"Uncommon",cash:[18500,6e4,62e4,44e5,38e6],time:[3,3,3,2,2],price:[12e5,125e5,15e6,15e8]},{name:"Slime Monster",color:"#2fa04a",class:"\u2694%EF%B8%8F",rarity:"Uncommon",cash:[35e3,14e4,1e6,11e6,11e7],time:[5,5,4,4,4],price:[16e5,15e6,2e8,23e8]},{name:"Jester",color:"#be1e2d",class:"\u2694%EF%B8%8F",rarity:"Rare",cash:[25e3,1e5,68e4,65e5,32e6],time:[3,3,2,2,1],price:[2e6,21e6,23e7,26e8]},{name:"Dragon",color:"#2fa04a",class:"\u2694%EF%B8%8F",rarity:"Rare",cash:[36e3,15e4,15e5,15e6,15e7],time:[4,4,4,4,4],price:[23e5,24e6,27e7,3e9]},{name:"Unicorn",color:"#f6afce",class:"\u2694%EF%B8%8F",rarity:"Epic",cash:[24e3,15e4,14e5,7e6,75e6],time:[2,2,2,1,1],price:[45e5,45e6,55e7,65e8]},{name:"Queen",color:"#9e1f63",class:"\u2694%EF%B8%8F",rarity:"Rare",cash:[24e3,95e3,95e4,97e5,95e6],time:[3,3,3,3,3],price:[19e5,2e7,23e7,25e8]},{name:"King",color:"#ee2640",class:"\u2694%EF%B8%8F",rarity:"Legendary",cash:[75e3,4e5,6e6,9e7,125e7],time:[5,5,5,5,5],price:[6e6,95e6,16e8,25e9]},{name:"Two of Spades",color:"#414042",class:"\u{1F3F0}",rarity:"Uncommon",cash:[4500,14e3,14e4,14e5,9e6],time:[1,1,1,1,1],price:[77e4,83e5,98e6,71e7]},{name:"Eat Me",color:"#d58c55",class:"\u{1F3F0}",rarity:"Uncommon",cash:[13e3,45e3,45e4,45e5,5e7],time:[2,2,2,2,2],price:[13e5,14e6,16e7,2e9]},{name:"Drink Me",color:"#dd7399",class:"\u{1F3F0}",rarity:"Uncommon",cash:[12e3,4e4,4e5,4e6,45e6],time:[2,2,2,2,2],price:[12e5,12e6,14e7,18e8]},{name:"Alice",color:"#4cc9f5",class:"\u{1F3F0}",rarity:"Uncommon",cash:[13e3,42e3,21e4,21e5,23e6],time:[2,2,1,1,1],price:[12e5,13e6,15e7,19e8]},{name:"Queen of Hearts",color:"#d62027",class:"\u{1F3F0}",rarity:"Uncommon",cash:[23e3,87e3,62e4,75e5,9e7],time:[4,4,3,3,3],price:[13e5,13e6,18e7,24e8]},{name:"Dormouse",color:"#89d6f8",class:"\u{1F3F0}",rarity:"Rare",cash:[17e3,68e3,7e5,35e5,35e6],time:[2,2,1,1,1],price:[2e6,22e6,25e7,28e8]},{name:"White Rabbit",color:"#ffcd05",class:"\u{1F3F0}",rarity:"Rare",cash:[26e3,105e3,11e6,77e5,72e6],time:[3,3,3,2,2],price:[2e6,23e6,28e7,29e8]},{name:"Cheshire Cat",color:"#dd7399",class:"\u{1F3F0}",rarity:"Rare",cash:[32e3,1e5,9e5,9e6,6e7],time:[4,3,3,3,2],price:[18e5,19e6,22e7,24e8]},{name:"Caterpillar",color:"#00c0f3",class:"\u{1F3F0}",rarity:"Epic",cash:[1e4,7e4,65e4,75e5,85e6],time:[1,1,1,1,1],price:[42e5,42e6,54e7,69e8]},{name:"Mad Hatter",color:"#914f93",class:"\u{1F3F0}",rarity:"Epic",cash:[38e3,25e4,15e5,14e6,8e7],time:[3,3,2,2,1],price:[48e5,48e6,52e7,66e8]},{name:"King of Hearts",color:"#c62127",class:"\u{1F3F0}",rarity:"Legendary",cash:[8e4,42e4,68e5,1e8,15e8],time:[5,5,5,5,5],price:[7e6,11e7,18e8,3e10]},{name:"Earth",color:"#416eb5",class:"\u{1F680}",rarity:"Uncommon",cash:[15e3,45e3,6e5,65e5,65e6],time:[3,3,3,3,3],price:[1e6,11e6,15e7,17e8]},{name:"Meteor",color:"#c68c3c",class:"\u{1F680}",rarity:"Uncommon",cash:[23e3,65e3,7e5,45e5,2e7],time:[5,4,3,2,1],price:[95e4,13e6,16e7,16e8]},{name:"Stars",color:"#19184d",class:"\u{1F680}",rarity:"Uncommon",cash:[1e4,4e4,2e5,2e6,18e6],time:[2,2,1,1,1],price:[14e5,14e6,15e7,15e8]},{name:"Alien",color:"#8dc63f",class:"\u{1F680}",rarity:"Uncommon",cash:[3e4,1e5,1e6,11e6,85e6],time:[4,4,4,4,4],price:[15e5,17e6,19e7,17e8]},{name:"Planet",color:"#9dc6ea",class:"\u{1F680}",rarity:"Rare",cash:[25e3,1e5,9e5,9e6,9e7],time:[3,3,3,3,3],price:[2e6,21e6,21e7,24e8]},{name:"UFO",color:"#a15095",class:"\u{1F680}",rarity:"Rare",cash:[17e3,7e4,7e5,7e6,7e7],time:[2,2,2,2,2],price:[21e5,23e6,25e7,28e8]},{name:"Spaceship",color:"#ffcb29",class:"\u{1F680}",rarity:"Epic",cash:[6e4,32e4,21e5,15e6,85e6],time:[5,4,3,2,1],price:[48e5,46e6,54e7,68e8]},{name:"Astronaut",color:"#9bd4ee",class:"\u{1F680}",rarity:"Legendary",cash:[45e3,26e4,25e5,38e6,55e7],time:[3,3,2,2,2],price:[65e5,1e8,17e8,27e9]},{name:"Lil Bot",color:"#3e564a",class:"\u{1F916}",rarity:"Uncommon",cash:[4e3,12e3,18e4,19e5,25e6],time:[1,1,1,1,1],price:[73e4,12e6,13e7,19e8]},{name:"Lovely Bot",color:"#f179af",class:"\u{1F916}",rarity:"Uncommon",cash:[16e3,65e3,65e4,48e5,42e6],time:[3,3,3,2,2],price:[13e5,14e6,17e7,16e8]},{name:"Angry Bot",color:"#f1613a",class:"\u{1F916}",rarity:"Uncommon",cash:[22e3,85e3,8e5,62e5,65e6],time:[4,4,4,3,3],price:[12e5,13e6,15e7,17e8]},{name:"Happy Bot",color:"#51ba6b",class:"\u{1F916}",rarity:"Uncommon",cash:[11e3,45e3,5e5,25e5,3e7],time:[2,2,2,1,1],price:[14e5,15e6,18e7,24e8]},{name:"Watson",color:"#d69b5a",class:"\u{1F916}",rarity:"Rare",cash:[24e3,1e5,1e6,1e7,1e8],time:[3,3,3,3,3],price:[2e6,22e6,24e7,26e8]},{name:"Buddy Bot",color:"#9dc6ea",class:"\u{1F916}",rarity:"Rare",cash:[22e3,95e3,65e4,65e5,65e6],time:[3,3,2,2,2],price:[19e5,21e6,23e7,25e8]},{name:"Brainy Bot",color:"#9ecf7a",class:"\u{1F916}",rarity:"Epic",cash:[5e4,25e4,21e5,21e6,17e7],time:[4,3,3,3,2],price:[5e6,46e6,5e8,67e8]},{name:"Mega Bot",color:"#d71f27",class:"\u{1F916}",rarity:"Legendary",cash:[8e4,43e4,42e5,62e6,1e9],time:[5,5,3,3,3],price:[7e6,12e7,19e8,35e9]}],run:function(){var e=d(),t=this.data.find(function({name:e}){return e.toLowerCase()==this},c("Enter blook name:").toLowerCase());t?(10<=e.state.blooks.length&&l("Choose a blook to replace"),e.waiting=!1,e.chooseBlook(Object.assign({},t))):l("That is not a valid blook!")}},{name:"Free Upgrades",description:"Sets upgrade prices to 0 for all current blooks",run:function(){const t=[0,0,0,0];var e=d();e.setState({blooks:e.state.blooks.map(e=>(e.price=t,e))})}},{name:"Max Blooks",description:"Maxes out all your blooks' levels",run:function(){d().state.blooks.forEach(e=>e.level=4)}},{name:"Remove Glitches",description:"Removes all enemy glitches",run:function(){var e=d();e.setState({bits:0,ads:[],hazards:[],color:"",lol:!1,joke:!1,slow:!1,dance:!1,glitch:"",glitcherName:"",glitcherBlook:""}),clearTimeout(e.adTimeout),clearInterval(e.hazardInterval),clearTimeout(e.nightTimeout),clearTimeout(e.glitchTimeout),clearTimeout(e.lolTimeout),clearTimeout(e.jokeTimeout),clearTimeout(e.slowTimeout),clearTimeout(e.danceTimeout),clearTimeout(e.nameTimeout)}},{name:"Send Glitch",description:"Sends a glitch to everyone else playing",data:{lb:"Lunch Break",as:"Ad Spam",e37:"Error 37",nt:"Night Time",lo:"#LOL",j:"Jokester",sm:"Slow Mo",dp:"Dance Party",v:"Vortex",r:"Reverse",f:"Flip",m:"Micro"},run:function(){var e=d(),t=Object.keys(this.data)[Math.floor(12*Math.random())];e.safe=!0,e.props.liveGameController.setVal({path:%60c/\${e.props.client.name}/tat%60,val:t}),l(%60Sent a \${this.data[t]} glitch%60)}},{name:"Set All MegaBot",description:"Sets all your blooks to maxed out Mega Bots",run:function(){d().setState({blooks:Array.from({length:10},()=>({name:"Mega Bot",color:"#d71f27",class:"\u{1F916}",rarity:"Legendary",cash:[8e4,43e4,42e5,62e6,1e9],time:[5,5,3,3,3],price:[7e6,12e7,19e8,35e9],active:!1,level:4,bonus:5.5}))})}},{name:"Set Cash",description:"Sets amount of cash you have",run:function(){d().setState({cash:parseInt(c("How much cash would you like?"))||0})}}],racing:[{name:"Instant Win",description:"Instantly Wins the race",run:function(){var e=d();e.setState({progress:e.state.goalAmount}),e.props.liveGameController.setVal({path:"c/"+e.props.client.name+"/pr",val:e.state.goalAmount})}},{name:"Set Questions",description:"Sets the number of questions left",run:function(){var e=d(),t=e.props.client.amount-(parseInt(c("How many questions left do you want?"))||0);e.setState({progress:t}),e.props.liveGameController.setVal({path:"c/"+e.props.client.name+"/pr",val:t})}}],rush:[{name:"Set Blooks",description:"Sets amount of blooks you or your team has",run:function(){var e=parseInt(c("How many blooks do you want?"))||0,t=d();t.setState({numBlooks:e}),t.props.liveGameController.setVal({path:(t.isTeam?"a/":"c/")+t.props.client.name+"/bs",val:e})}},{name:"Set Defense",description:"Sets amount of defense you or your team has (Max 4)",run:function(){var e=Math.min(parseInt(c("How much defense do you want? (Max 4)"))||0,4),t=d();t.setState({numDefense:e}),t.props.liveGameController.setVal({path:(t.isTeam?"a/":"c/")+t.props.client.name+"/d",val:e})}}],tower:[{name:"Fill Deck",description:"Fills your deck with every maxed out card and artifact (Only works on towers page)",run:function(){if("/tower/map"==window.__blPath()){var e=d();e.props.tower.artifacts="Medical Kit|Fury Relic|Survival Guide|Steel Socks|Piggy Bank|Lucky Feather|Coupon|Cheese|Tasty Egg|Training Weights|Mighty Shield|Toxic Waste|Lifeline Totem|Cursed Hourglass|Band-Aid|Elder Coins|Captain's Anchor|Chess Pieces|Pink Hippo|Anorak's Wizard Cap|Dave's Doggo|Anubis' Obelisk|Farm Tractor|Magic Seedling|Just A Bone|Cozy Igloo|King's Crown|Sacred Scroll".split("|"),e.props.tower.cards="Chick,\u{1F33D}|Chicken,\u{1F33D}|Cow,\u{1F33D}|Goat,\u{1F33D}|Horse,\u{1F33D}|Pig,\u{1F33D}|Sheep,\u{1F33D}|Duck,\u{1F33D}|Dog,\u{1F33D}|Cat,\u{1F43E}|Rabbit,\u{1F43E}|Goldfish,\u{1F43E}|Hamster,\u{1F43E}|Turtle,\u{1F43E}|Kitten,\u{1F43E}|Puppy,\u{1F43E}|Bear,\u{1F332}|Moose,\u{1F332}|Fox,\u{1F332}|Raccoon,\u{1F332}|Squirrel,\u{1F332}|Owl,\u{1F332}|Hedgehog,\u{1F332}|Baby Penguin,\u2744%EF%B8%8F|Penguin,\u2744%EF%B8%8F|Arctic Fox,\u2744%EF%B8%8F|Snowy Owl,\u2744%EF%B8%8F|Polar Bear,\u2744%EF%B8%8F|Arctic Hare,\u2744%EF%B8%8F|Seal,\u2744%EF%B8%8F|Walrus,\u2744%EF%B8%8F|Tiger,\u{1F334}|Panther,\u{1F334}|Cockatoo,\u{1F334}|Orangutan,\u{1F334}|Anaconda,\u{1F334}|Macaw,\u{1F334}|Jaguar,\u{1F334}|Capuchin,\u{1F334}|Toucan,\u{1F334}|Parrot,\u{1F334}|Elf,\u2694%EF%B8%8F|Witch,\u2694%EF%B8%8F|Wizard,\u2694%EF%B8%8F|Fairy,\u2694%EF%B8%8F|Slime Monster,\u2694%EF%B8%8F|Jester,\u2694%EF%B8%8F|Dragon,\u2694%EF%B8%8F|Unicorn,\u2694%EF%B8%8F|Queen,\u2694%EF%B8%8F|King,\u2694%EF%B8%8F|Snow Globe,\u2603%EF%B8%8F|Holiday Gift,\u2603%EF%B8%8F|Hot Chocolate,\u2603%EF%B8%8F|Gingerbread Man,\u2603%EF%B8%8F|Gingerbread House,\u2603%EF%B8%8F|Holiday Wreath,\u2603%EF%B8%8F|Snowman,\u2603%EF%B8%8F|Santa Claus,\u2603%EF%B8%8F|Two of Spades,\u{1F3F0}|Eat Me,\u{1F3F0}|Drink Me,\u{1F3F0}|Alice,\u{1F3F0}|Queen of Hearts,\u{1F3F0}|Dormouse,\u{1F3F0}|White Rabbit,\u{1F3F0}|Cheshire Cat,\u{1F3F0}|Caterpillar,\u{1F3F0}|Mad Hatter,\u{1F3F0}|King of Hearts,\u{1F3F0}".split("|").map(e=>{var[e,t]=e.split(",");return{strength:20,charisma:20,wisdom:20,class:t,blook:e}});try{e.props.addTowerNode()}catch{}e.setState({showDeck:!1})}else l("You need to be on the map to run this cheat!")}},{name:"Max Cards",description:"Maxes out all the cards in your deck",run:function(){if("/tower/map"==window.__blPath()){var e=d();e.props.tower.cards.forEach(e=>{e.strength=20,e.charisma=20,e.wisdom=20});try{e.forceUpdate()}catch{}}else l("You need to be on the map to run this cheat!")}},{name:"Max Health",description:"Fills the player's health",run:function(){"/tower/battle"==window.__blPath()?d().setState({myHealth:100,myLife:100}):l("You need to be in battle to run this cheat!")}},{name:"Max Card Stats",description:"Maxes out player's current card (Only works on attribute select page)",run:function(){var e=d();"select"!==e.state.phase?l("You must be on the attribute selection page!"):e.setState({myCard:{...e.state.myCard,strength:20,charisma:20,wisdom:20}})}},{name:"Min Enemy Stats",description:"Makes the enemy card stats all 0 (Only works on attribute select page)",run:function(){var e=d();"select"!==e.state.phase?l("You must be on the attribute selection page!"):e.setState({enemyCard:{...e.state.enemyCard,strength:0,charisma:0,wisdom:0}})}},{name:"Set Coins",description:"Try's to set amount of tower coins you have",run:function(){if("/tower/battle"==window.__blPath())try{d().props.setTowerCoins(parseInt(c("How many coins would you like?"))||0)}catch{}else l("You need to be in battle to run this cheat!")}}],kingdom:[{name:"Choice ESP",description:"Shows you what will happen if you say Yes or No",type:"toggle",enabled:!1,data:null,run:function(){this.enabled?(this.enabled=!1,clearInterval(this.data),Array.prototype.forEach.call(document.querySelectorAll(".choiceESP"),e=>e.remove()),this.data=null):(this.enabled=!0,this.data=setInterval(o=>{let a=d(),n=Array.prototype.reduce.call(document.querySelectorAll("[class*=statContainer]"),(e,t,a)=>(e[o[a]]=t,e),{});"choice"==a.state.phase&&(Array.prototype.forEach.call(document.querySelectorAll(".choiceESP"),e=>e.remove()),Object.keys(a.state.guest.yes||{}).forEach(e=>{var t;null!=n[e]&&((t=document.createElement("div")).className="choiceESP",t.style="font-size: 24px; color: rgb(75, 194, 46); font-weight: bolder;",t.innerText=String(a.state.guest.yes[e]),n[e].appendChild(t))}),Object.keys(a.state.guest.no||{}).forEach(e=>{var t;null!=n[e]&&((t=document.createElement("div")).className="choiceESP",t.style="font-size: 24px; color: darkred; font-weight: bolder;",t.innerText=String(a.state.guest.no[e]),n[e].appendChild(t))}),Array.prototype.forEach.call(document.querySelectorAll("[class*=guestButton][role=button]"),e=>e.onclick=()=>Array.prototype.forEach.call(document.querySelectorAll(".choiceESP"),e=>e.remove())))},50,["materials","people","happiness","gold"]))}},{name:"Disable Tax Toucan",description:"Tax evasion",run:function(){d().taxCounter=Number.MAX_VALUE}},{name:"Max Stats",description:"Sets all resources to the max",run:function(){d().setState({materials:100,people:100,happiness:100,gold:100})}},{name:"Set Guests",description:"Sets the amount of guests you've seen",run:function(){d().setState({guestScore:parseInt(c("How many guests do you want?"))||0})}},{name:"Skip Guest",description:"Skips the current guest",run:function(){d().nextGuest()}}],toy:[{name:"Remove Distractions",description:"Removes all enemy distractions",run:function(){d().setState({fog:!1,dusk:!1,wind:!1,plow:!1,blizzard:!1,force:!1,canada:!1,trees:[!1,!1,!1,!1,!1,!1,!1,!1,!1,!1]})}},{name:"Send Distraction",description:"Sends a distraction to everyone else playing",data:Object.entries({c:"Oh Canada",b:"Blizzard",f:"Fog Spell",d:"Dark & Dusk",w:"Howling Wind",g:"Gift Time!",t:"TREES",s:"Snow Plow",fr:"Use The Force"}),run:function(){var[e,t]=this.data[Math.floor(Math.random()*this.data.length)],a=d();a.safe=!0,a.props.liveGameController.setVal({path:%60c/\${a.props.client.name}/tat%60,val:e}),l(%60Sent a \${t} distraction%60)}},{name:"Set Toys",description:"Sets amount of toys",run:function(){var e=parseInt(c("How many toys would you like?"))||0,t=d();t.setState({toys:e}),t.props.liveGameController.setVal({path:"c/"+t.props.client.name+"/t",val:e})}},{name:"Set Toys Per Question",description:"Sets amount of toys per question",run:function(){d().setState({toysPerQ:parseInt(c("How many toys per question would you like?"))||0})}},{name:"Swap Toys",description:"Swaps toys with someone",run:function(){let o=d();o.props.liveGameController.getDatabaseVal("c",e=>{if(null!=e){var t=[];for(const a in e)a!=o.props.client.name&&t.push({name:a,blook:e[a].b,toys:e[a].t||0});o.setState({choosingPlayer:!1,players:t,phaseTwo:!0,stage:"prize",choiceObj:{type:"swap"}},()=>setTimeout(()=>o.setState({choosingPlayer:!0}),300))}})}}],flappy:[{name:"Toggle Ghost",description:"Lets you go through the pipes",type:"toggle",enabled:!1,run:function(){this.enabled=!this.enabled;for(const e of Object.values(document.querySelector("#phaser-bouncy"))[0].return.updateQueue.lastEffect.deps[0].current.config.sceneConfig.physics.world.bodies.entries)if(e.gameObject.frame.texture.key.startsWith("blook")){e.checkCollision.none=this.enabled,e.gameObject.setAlpha(this.enabled?.5:1);break}}},{name:"Set Score",description:"Sets flappy blook score",run:function(){Object.values(document.querySelector("#phaser-bouncy"))[0].return.updateQueue.lastEffect.deps[1](parseInt(c("What do you want to set your score to?"))||0)}}]};var h=document.createElement("details");h.innerHTML='<summary style="padding: 10px; font-size: 1.5em; font-weight: bolder">Global</summary>';for(let t of m.global){let e=b(t.name);e.style.backgroundColor="toggle"==t.type?t.enabled?"#47A547":"#A02626":"hsl(0, 0%, 20%)",e.onclick=()=>{try{t.run()}finally{e.style.backgroundColor="toggle"==t.type?t.enabled?"#47A547":"#A02626":"hsl(0, 0%, 20%)"}},h.appendChild(e)}h.open=!1,h.style.paddingBottom="10px",t.appendChild(h);let y=document.createElement("div");t.appendChild(y),console.log(m);const f=e=>{if(e&&m[e])for(let t of m[e]){let e=b(t.name);e.style.backgroundColor="toggle"==t.type?t.enabled?"#47A547":"#A02626":"hsl(0, 0%, 20%)",e.onclick=()=>{try{t.run()}finally{e.style.backgroundColor="toggle"==t.type?t.enabled?"#47A547":"#A02626":"hsl(0, 0%, 20%)"}},y.appendChild(e),y.appendChild(document.createElement("br"))}};setTimeout(()=>f(w()),50);var g=function(e){let t=window.__blPath();const a=setInterval(()=>{window.__blPath()!=t&&(t=window.__blPath(),e(t))},50);return()=>clearInterval(a)}(e=>{var t=w();curPageEl.innerText=w(!0)?"Current gamemode: "+w(!0):"No game detected",y.innerHTML="",f(t)});function b(e){var t=document.createElement("button");return t.classList.add("cheat"),t.innerText=e,t}function w(e){switch(window.__blPath()){case"/play/gold":case"/play/gold/final":case"/gold/play/landing":return e?"Gold Quest":"gold";case"/play/hack":case"/play/hack/final":case"/hack/play/landing":return e?"Crypto":"hack";case"/play/fishing":case"/play/fishing/final":case"/fish/play/landing":return e?"Fishing Frenzy":"fish";case"/play/pirate":case"/play/pirate/final":case"/pirate/play/landing":return e?"Pirate's Voyage":"pirate";case"/play/defense2/load":case"/play/defense2":case"/play/defense2/final":case"/defense2/play/landing":return e?"Tower Defense 2":"defense2";case"/play/brawl/start":case"/play/brawl/settings":case"/play/brawl":case"/play/brawl/final":case"/brawl/play/landing":return e?"Monster Brawl":"brawl";case"/play/dino":case"/play/dino/final":case"/dino/play/landing":return e?"Deceptive Dinos":"dino";case"/play/battle-royale/match/preview":case"/play/battle-royale/question":case"/play/battle-royale/answer/sent":case"/play/battle-royale/answer/result":case"/play/battle-royale/match/result":case"/play/battle-royale/final":case"/royale/play/landing":return e?"Battle Royale":"royale";case"/defense/load":case"/defense":case"/defense/final":case"/defense/play/landing":return e?"Tower Defense":"defense";case"/cafe/load":case"/cafe":case"/cafe/shop":case"/cafe/final":case"/cafe/play/landing":return e?"Cafe":"cafe";case"/play/factory":case"/play/factory/settings":case"/play/factory/start":case"/play/factory/final":case"/factory/play/landing":return e?"Factory":"factory";case"/play/racing":case"/play/racing/final":case"/racing/play/landing":return"racing";case"/play/rush":case"/play/rush/final":case"/rush/play/landing":return e?"Blook Rush":"rush";case"/play/classic/get-ready":case"/play/classic/question":case"/play/classic/answer/sent":case"/play/classic/answer/result":case"/play/classic/standings":case"/play/classic/final":case"/classic/play/landing":return e?"Classic":"classic";case"/tower/load":case"/tower/start":case"/tower/map":case"/tower/battle":case"/tower/rest":case"/tower/risk":case"/tower/shop":case"/tower/victory":case"/tower/final":case"/tower/play/landing":return e?"Tower of Doom":"tower";case"/kingdom/start":case"/kingdom":case"/kingdom/final":case"/kingdom/play/landing":return e?"Crazy Kingdom":"kingdom";case"/play/toy":case"/play/toy/final":case"/toy/play/landing":return e?"Santa's Workshop":"toy";case"/play/lobby":return e?"Lobby":"flappy";default:return!1}}function v(e){"KeyE"==e.code&&(a.hidden=!a.hidden)}addEventListener("keypress",v)};let m=new Image;m.src="https://raw.githubusercontent.com/Blooket-Council/Blooket-Cheats/main/autoupdate/timestamps/mobileGui.png?"+Date.now(),m.crossOrigin="Anonymous",m.onload=function(){var e=document.createElement("canvas").getContext("2d");e.drawImage(m,0,0,this.width,this.height);let t=e.getImageData(0,0,this.width,this.height)["data"],a="",o,n=0;for(;n<t.length;){var s=String.fromCharCode(t[n% 4==3&&n++,n++]+256*t[n% 4==3&&n++,n++]);if(a+=s,"/"==s&&"*"==o)break;o=s}let r,l=d,i="There was an error checking for script updates. Run cheat anyway?";try{[r,l,i]=a.match(/LastUpdated: (.+?); ErrorMessage: "((.|\\n)+?)"/)}catch(e){}((u=parseInt(l))<=d||c.contentWindow.confirm(i))&&p()},m.onerror=m.onabort=()=>{m.onerror=m.onabort=null,p(),document.querySelector("iframe").contentWindow.alert("It seems the GitHub is either blocked or down.\\n\\nIf it's NOT blocked, join the Discord server for updates\\nhttps://discord.gg/jHjGrrdXP6\\n(The cheat will still run after this alert)")}})();
  }

  // The bookmarklet expects to run with the React root present. Wait for it.
  var tries = 0;
  function tick() {
    if (ready()) {
      try { launch(); } catch (e) { console.error('[blooket-proxy] cheat init failed:', e); }
    } else if (++tries < 80) {
      setTimeout(tick, 150);
    } else {
      console.warn('[blooket-proxy] React root never appeared; cheats not initialised.');
    }
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    tick();
  } else {
    document.addEventListener('DOMContentLoaded', tick);
  }
})();
`;

// src/dashboard-entry.ts
var BARE_DIRECTORY = "/bare/";
var memoryDB = /* @__PURE__ */ new Map();
var bare = createBareServer(BARE_DIRECTORY, {
  logErrors: true,
  database: memoryDB
});
var lastCleanup = 0;
var dashboard_entry_default = {
  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname;
    if (path === "/" || path === "/index.html") {
      return new Response(public_default, {
        headers: { "content-type": "text/html; charset=utf-8" }
      });
    }
    if (path === "/cheats.js") {
      return new Response(cheats_default, {
        headers: {
          "content-type": "application/javascript; charset=utf-8",
          "cache-control": "public, max-age=300"
        }
      });
    }
    if (path === "/shim.js") {
      return new Response(buildShim(url.searchParams.get("orig") || ""), {
        headers: {
          "content-type": "application/javascript; charset=utf-8",
          "cache-control": "no-store"
        }
      });
    }
    if (path === BROWSE_PREFIX || path.startsWith(BROWSE_PREFIX)) {
      return await handleBrowse(request);
    }
    if (path.startsWith(BARE_DIRECTORY)) {
      const now = Date.now();
      if (now - lastCleanup > 6e4) {
        lastCleanup = now;
        try {
          await cleanupDatabase(memoryDB);
        } catch {
        }
      }
      return await bare.routeRequest(request);
    }
    return new Response("Not Found", { status: 404 });
  }
};
function buildShim(orig) {
  const safe = orig.replace(/\\/g, "\\\\").replace(/</g, "\\u003c").replace(/"/g, '\\"');
  return `window.__BLOOKET_ORIG_URL__="${safe}";try{var u=new URL(window.__BLOOKET_ORIG_URL__);window.__BLOOKET_ORIG_PATH__=u.pathname;window.__BLOOKET_ORIG_HOST__=u.host;window.__BLOOKET_ORIG_HREF__=u.href;}catch(e){window.__BLOOKET_ORIG_PATH__="/";window.__BLOOKET_ORIG_HOST__="play.blooket.com";window.__BLOOKET_ORIG_HREF__=window.__BLOOKET_ORIG_URL__||"https://play.blooket.com/";}window.__blPath=function(){return window.__BLOOKET_ORIG_PATH__;};window.__blHref=function(){return window.__BLOOKET_ORIG_HREF__;};window.__blHost=function(){return window.__BLOOKET_ORIG_HOST__;};`;
}
export {
  dashboard_entry_default as default
};
